#!/usr/bin/perl -w

use warnings;
use strict;
use CGI qw/:all *table *Tr *td *h1/; 

my $cgiConf = "cgi.csv";
my $alarmConf = "alarm.csv";
my @cgiRows;
my @alarmRows;
my $enbIpPara = "enbip";
my %summaryData;
my %dateSort;
my %rrhSort;
my @thresholdItems;

sub sort_date_rrh {
  my ($data,$dateS,$rrh) = @_;
  my ($dateCount,$rrhCount) = 0;

  foreach my $kdate (keys %{$data}) {
    foreach my $krrh (keys %{${$data}{$kdate}}) {
      foreach my $kitems (keys %{${$data}{$kdate}{$krrh}}) {
        $rrhCount += ${$data}{$kdate}{$krrh}{$kitems};
        $dateCount += ${$data}{$kdate}{$krrh}{$kitems};
      }
      ${$rrh}{$kdate}{$krrh} = $rrhCount;
      $rrhCount = 0;
    }
    ${$dateS}{$kdate} = $dateCount;
    $dateCount = 0;
  }
}

sub get_hist_list {
  my ( $current, $interval, $hist ) = @_; 
  my @split = split('_',$current);
  my $day = $split[-1];
  my $month = $split[-2];
  my $year = $split[-3];

  push( @{$hist}, $current );
  my $ical = Date::ICal->new( year => $year, month => $month, day => $day, offset => '+0000');
  foreach ( 1..$interval-1 ) {
    $ical->add( day => -1 );
    $split[-1] = sprintf( "%02d", $ical->day );
    $split[-2] = sprintf( "%02d", $ical->month );
    $split[-3] = $ical->year;
    my $new_file_name = join('_',@split);
    push( @{$hist}, $new_file_name );
  }
}

sub get_absolute_path {
  my $QuerystringFromEnv=$ENV{SCRIPT_FILENAME};
  my ($path) = split(/=/,$QuerystringFromEnv);
  $path =~ tr/+//;

  my @splitPath = split('/',$path);
  pop @splitPath;
  
  return join('/',@splitPath)."/";
}

sub save_history_data {
  my ($cTime,$dirs,$enbIP,$summary,$span,$items) = @_;
  my @historyFile;
  my $patternItems = 11;
  my $i = 0;
  my (@splitFile,@splitAbsFile);

  get_hist_list($cTime,$span,\@historyFile);
  foreach my $perDate ( @historyFile ) {
    my $query = $dirs."eNB_".$enbIP."*".$perDate."_report";
    #print $query,"<BR> \n";
    my @fileList = qx/ls $query/;
    foreach my $perEnbList ( @fileList ) {
      #chomp($perEnbList);
      @splitAbsFile = split('/',$perEnbList);
      @splitFile = split('_',$splitAbsFile[-1]);
      my @tailResult = qx/tail -$patternItems $perEnbList/;
      next unless $tailResult[0] =~ /SUMMARY/;

      shift @tailResult;
      pop @tailResult;
      pop @tailResult;
      foreach my $perLine (@tailResult) {
        chomp($perLine);
        if ( $perLine =~ /^\s+(\w+\(\w+\))\s+:\s+(\d+)/ || $perLine =~ /^\s+(\w+)\s+:\s+(\d+)/ ) {
          #print "$1 : $2\n";
          ${$summary}{$perDate}{$splitFile[3]}{$1} = $2;
          if ( $i == 0 ){ # if first time, save all alarm threshold type into a list
            push @{$items}, $1;
          }
        }
      }
      $i++;
    }
  }
}

sub output_table_head {
  my ($tableHead) = @_;

  print start_Tr;
  foreach ( @{$tableHead} ) {
    print start_td({bgcolor=>'#cccccc'}),$_,end_td;
  }
  print end_Tr;
}

sub output_table_data {
  my ($data,$tableHead,$dateS,$rrhS) = @_;
  my $tDate = "0000_00_00";
  my @sliceHead = @{$tableHead}[4..@{$tableHead}-1];
  my $c0Thres = 5;
  my $c1Thres = 3;
  my $c2Thres = 1;
  my $c3Thres = 0;

  #foreach my $perDate ( sort { ${$data}{$b} <=> ${$data}{$a} } keys %{$data} ) {
  foreach my $perDate ( reverse sort keys %{$data} ) {
    foreach my $rrh (sort keys %{${$data}{$perDate}}) {
      if ( $tDate eq $perDate ) {
        print start_Tr;
	print start_td,'',end_td;
	print start_td,'',end_td;
      }
      else {
        print start_Tr;
	print start_td,$perDate,end_td;
	print start_td,${$dateS}{$perDate},end_td;

	$tDate = $perDate;
      }
      print start_td,$rrh,end_td;
      print start_td,${$rrhS}{$perDate}{$rrh},end_td;

      foreach ( @sliceHead ) {
        if ( ${$data}{$perDate}{$rrh}{$_} >= $c0Thres ) {
          print start_td({bgcolor=>'#ff0000'});
	}
        elsif ( ${$data}{$perDate}{$rrh}{$_} >= $c1Thres ) {
          print start_td({bgcolor=>'#ffcc99'});
	}
        elsif ( ${$data}{$perDate}{$rrh}{$_} >= $c2Thres ) {
          print start_td({bgcolor=>'#ffff99'});
	}
        elsif ( ${$data}{$perDate}{$rrh}{$_} >= $c3Thres ) {
          print start_td({bgcolor=>'#99ff99'});
	}
	print ${$data}{$perDate}{$rrh}{$_};
	print end_td;
      }
      print end_Tr;
    }
  }
}

sub make_html {
  my ($data,$items,$dateS,$rrhS) = @_;
  my @sorted_items = sort @{$items};

  unshift @sorted_items,"RRH Issue";
  unshift @sorted_items,"RRH";
  unshift @sorted_items,"Total Issue";
  unshift @sorted_items,"Date";
  print start_table({-border=>'1',-cellspacing=>'0',-cellpadding=>'0'});
  output_table_head( \@sorted_items );
  output_table_data( $data,\@sorted_items,$dateS,$rrhS );
  print end_table;
=comment
  print table(
    {-border=>'1',-cellspacing=>'5',-cellpadding=>'5',size=>'10'},
    Tr (
      {-align=>'left',-valign=>'top'},
      [
        th( [@{$items}] ),
      ]
    )
  );
=cut
}

my $q = CGI->new;
my $enbIP = $q->param($enbIpPara);
#print "enb IP is : $enbIP","<BR> \n";
print $q->header;
print $q->start_html(
    -title=>"ENB $enbIP HISTORY QUERY",
#    -link=>{-rel=>'stylesheet',-type=>'text/css',-href=>'cover.css'}
  );
print $q->h1({bgcolor=>'#3399ff'},"ENB $enbIP HISTORY QUERY");

my $cgiPath = get_absolute_path;
unshift @INC,$cgiPath;
require "RSM.pm";

if ( RSM::read_csv( $cgiConf, $cgiPath, \@cgiRows, 7 ) ) {
  print "read cgi.csv error!","<BR> \n";
  exit 1;
}
if ( RSM::read_csv( $alarmConf, $cgiPath, \@alarmRows, 4 ) ) {
  print "read alarm.csv error!","<BR> \n";
  exit 1;
}
my ($span) = @{$alarmRows[0]};

my $cTime = RSM::current_time(2);
##DEBUG
#$cTime = "2013_04_09";
save_history_data( $cTime, ${$cgiRows[0]}[0], $enbIP, \%summaryData, $span, \@thresholdItems );
sort_date_rrh( \%summaryData, \%dateSort, \%rrhSort );
make_html( \%summaryData,\@thresholdItems,\%dateSort,\%rrhSort );
print $q->end_html;

__END__
