#/usr/bin/perl -w

use strict;
use warnings;
use Net::SSH::Expect;
use List::Util qw(max min);
use File::Spec;
#use Net::Ping;
use Net::Ping::External qw(ping);

###########################################################
#  sub connect_enb                                        #
#    connect to each enb by ssh                           #
#                                                         #
#  input para:                                            #
#    $ssh  - ssh connection ref                           #
#    $host - enb host ip                                  #
#    $user - enb login name                               #
#    $pwd  - enb login password                           #
#  output para:                                           #
#    $ssh  - ssh connection instance                      #
#  return:                                                #
#    0 : normal return                                    #
#    1 : error return                                     #
###########################################################
sub connect_enb {
  my ($ssh, $host, $user, $pwd) = @_;
  my $res;

	print "------------------- : start sub connect_enb!\n";
  ${$ssh} = Net::SSH::Expect->new (
    host => "$host",
    user => "$user",
    password => "$pwd",
    raw_pty => 1 ); 

  my $login_output = ${$ssh}->login() or do {
	  return 1;
  };

  # print $login_output, "\n";
  $res = ${$ssh}->exec("sh");
	# print "$res\n";
	if ( !defined($res) ) {
	  RSM::write_log( *MFILE, "KO! ssh connect failure!" );
	  ${$ssh}->close;
	  return 1;
	}
	else {
	  print "------------------- : ssh connect success!\n";
	  print "------------------- : exit sub connect_enb!\n";
    return 0;
	}
}

###########################################################
#  sub connect_rrh                                        #
#    connect to each rrh by telnet                        #
#                                                         #
#  input para:                                            #
#    $ssh   - ssh connection ref                          #  
#    $rrhip - rrh ip                                      #
#    $login_expect - login expect key words               #
#    $login - rrh login name                              #
#    $pwd_expect - password expect key words              #
#    $pwd   - rrh login password                          #
#    $cmd   - execute command after login rrh success     #
#  output para:                                           #
#    no output para                                       #
#  return:                                                #
#    0 : normal return                                    #
#    1 : error return                                     #
###########################################################
sub connect_rrh {
  my ($ssh, $rrhip, $login_expect, $login, $pwd_expect, $pwd, $cmd) = @_;
	print "------------------- : start sub connect_rrh!\n";

  ${$ssh}->send("telnet $rrhip");
  ${$ssh}->waitfor("$login_expect", 5) or do {
	  ${$ssh}->send("\cC");
	  return 1;
	};
  ${$ssh}->send($login);
  ${$ssh}->waitfor("$pwd_expect", 2) or do {
	  ${$ssh}->send("\cC");
	  return 1;
  };
  ${$ssh}->send($pwd);
  ${$ssh}->waitfor("->",3) or do {
	  sleep 65;
	  return 1;
  };
  ${$ssh}->exec($cmd);

	print "------------------- : exit sub connect_rrh!\n";
  return 0;
}

###########################################################
#  sub DetectRrhType                                      #
#    Detect RRH type to see if it match configuration     #
#                                                         #
#  input para:                                            #
#    $ssh   - ssh connection ref                          #  
#    $showCmd   - the Command executed in eNB             #
#    $hwType    - read from configuration file            #
#  output para:                                           #
#    no output para                                       #
#  return:                                                #
#    0 : not match hwType                                 #
#    1 : match hwType                                     #
###########################################################
sub DetectRrhType{
  my $ssh = shift;
	my $showCmd = shift;
	my $hwType = shift;
	my $res;

  $res = ${$ssh}->exec($showCmd);
  my @hwTypeRes = split(/\n/,$res);
  # print "$hwTypeRes[5]\n";
  my @typeVal = split(/:/,$hwTypeRes[5]);
  # print "@typeVal\n";
  $typeVal[1] =~ s/^\s+//;
  # print "$typeVal[1]\n";
	foreach ( 0..@{$hwType}-1 ) {
	  # print "${$hwType}[$_]...\n";
	  if ( $typeVal[1] =~ /${$hwType}[$_]/ ) {
		  return 1;
		}
	}

	return 0;
}

###########################################################
#  sub validate_tdd_rrh                                   #
#    see if rrhs we expect is under this eNB              #
#                                                         #
#  input para:                                            #
#    $ssh    - enb ssh connection ref                     #
#    $hwType - hardware type ref                          #
#  output para:                                           #
#    no output para                                       #
#  return:                                                #
#    0 : normal return                                    #
#    1 : error return                                     #
###########################################################
sub validate_tdd_rrh {
  my $ssh = shift;
	my $hwType = shift;
	my $rrhId = shift;

  my ($res, $validatePath, $retRrh);

  # 20130320
	$retRrh = 1;
	my $checkStr = "Unknown level";
	my $validatePathPre = "cd /OAM-C/oamctrl/CfgMgrRRH-";
	my @rrhDir = qw(1100 2100 3100 4100 5100 6100);
  # 20130320
	my $validateCmd = "show";

  $res = ${$ssh}->exec("exit");
	print "------------------- : start sub validate_tdd_rrh!\n";

  # 20130320
  foreach ( @rrhDir ) {
    $validatePath = $validatePathPre.$_;
    $res = ${$ssh}->exec($validatePath);
		# print $res,"\n";
		if ( $res =~ /$checkStr/ ) {
		  push @{$rrhId}, '0';
		}
		else {
		  if( DetectRrhType($ssh, $validateCmd, $hwType) ){
			  # return 1 means it's 8*5 rrh, hwType is '0733'
				$retRrh = 0;
				push @{$rrhId}, '1';
			}
			else{
			  push @{$rrhId}, '0';
			}
		}
	}

	print "------------------- : exit sub validate_tdd_rrh!\n";
	$res = ${$ssh}->exec("sh");
	return $retRrh;
}

###########################################################
#  sub find_rrh_ip                                        #
#    find rrhs ip in the enb by command "netstat ..."     #
#                                                         #
#  input para:                                            #
#    $ssh   - enb ssh connection ref                      #  
#    $data  - to place rrh IP                             #
#    $rrhId - rrh Id of eNB fiber port                    #
#  output para:                                           #
#    no output para                                       #
#  return:                                                #
#    0 : normal return                                    #
#    1 : error return                                     #
###########################################################
sub find_rrh_ip {
  my ($ssh,$data,$rrhId) = @_;
	my $findRrhIp = "netstat -an|grep 1307|grep -v LISTEN|awk -F' ' '\{print \$5\}'";
	print "------------------- : start sub find_rrh_ip!\n";
	
  my $res = ${$ssh}->exec($findRrhIp);
  my @rrh = split(/\n/,$res);
  shift @rrh;
  pop @rrh;
  foreach ( @rrh ) {
	  chomp($_);
		next if ( length($_)<=8 );
	  my @ip = split(':',$_);
		my @eachField = split(/\./,$ip[0]);
		if ( $eachField[2] <= 134 && $eachField[2] >= 129 ) {
		  if ( ${$rrhId}[$eachField[2]-129] eq '1' ) {
	      push @{$data}, $ip[0];
		  }
		}
		elsif ( $eachField[2] <= 150 && $eachField[2] >= 145 ) {
		  if ( ${$rrhId}[$eachField[2]-145] eq '1' ) {
	      push @{$data}, $ip[0];
		  }
		}
		else {
		}
  }

  # print "@{$data}\n";
  foreach ( @{$data} ) {
	  if ( !/^[0-9]+.[0-9]+.[0-9]+.[0-9]+$/ ) {
	    return 1;
	  }
  }

	print "------------------- : exit sub find_rrh_ip!\n";
  return 0;
}

#######################################################
##################        main     ####################
#######################################################
if ( $#ARGV < 0 ) {
  print "usage: perl monitor.pl \@ARGV\n";
  exit 1;
}
## define variables
my $groupId = shift @ARGV;
my @enbRows = @ARGV;
my $pathCurf = File::Spec->rel2abs(__FILE__);
my ($vol, $dirs, $file) = File::Spec->splitpath($pathCurf);
my $connectReportFile = $dirs.".monitor_group_${groupId}.log";
my $enbStr = "";
my $enbCsvWidth = 5;
my $rrhCsvWidth = 5;
unshift @INC,$dirs;
require "RSM.pm";
my ($line, $rrhTraceFileName, $ssh, $alarmFlag, $rrhHwType);
my (@rrhRows,@groupRows,@alarmRows,@patternRows);
my $rrhConf = "rrh.csv";
my $groupConf = "group.csv";
my $alarmConf = "alarm.csv";
my $patternConf = "pattern.csv";

my %allData = ();
my %summaryData = ();
my %allDataHist = ();
my %threshold = ();
my (@patternType,@keyType,@splitHwType );

## open the log file
open(MFILE, ">>$connectReportFile") or die "couldn't open the file\n";
select MFILE;
$| = 1;
RSM::write_log(*MFILE,"Enter group $groupId.");
foreach(0..@enbRows/$enbCsvWidth-1) {
  $enbStr = $enbStr." ".$enbRows[$_*$enbCsvWidth]; 
}
RSM::write_log(*MFILE,"group $groupId include below eNBs :$enbStr.");

## define ALRM signal 
$SIG{ALRM} = \&recv_sig_alrm;

## read csv file to get eNB info
if ( RSM::read_csv( $rrhConf, $dirs, \@rrhRows, 3 ) ) {
  RSM::write_log(*MFILE,"KO! open rrh.csv error, stop now!");
  exit 1;
}
## read csv file to get RRH info
if ( RSM::read_csv( $groupConf, $dirs, \@groupRows, 2 ) ) {
  RSM::write_log(*MFILE,"KO! open group.csv error, stop now!");
  exit 1;
}
$rrhHwType = ${$groupRows[0]}[4];
@splitHwType = split(',',$rrhHwType);
## read csv file to get alarm configuration
if ( RSM::read_csv( $alarmConf, $dirs, \@alarmRows, 4 ) ) {
  RSM::write_log(*MFILE,"KO! open alarm.csv error, stop now!");
  exit 1;
}
my ($histDayInterval,$txPathNum) = @{$alarmRows[0]};
## read csv file to get pattern configuration
if ( RSM::read_csv( $patternConf, $dirs, \@patternRows, 6 ) ) {
  RSM::write_log(*MFILE,"KO! open pattern.csv error, stop now!");
  exit 1;
}

## connect to each eNB and rrh to get trace
&get_trace;

RSM::write_log(*MFILE,"Exit group $groupId.");
close MFILE;
select STDIN;

###########################################################
#  sub get_trace                                          #
#    there is two loops, outter loop is eNB loop, inner   #
#  loop is rrh loop.                                      #
#    when telnet into each rrh, start to capture rrh      #
#  trace for a fix time which is defined in enb.csv       #
#                                                         #
#  input para:                                            #
#    no input para                                        #
#  output para:                                           #
#    no output para                                       #
#  return:                                                #
#    no return                                            #
###########################################################
sub get_trace {
  my @rrhPerEnb;
	my @rrhIdPerEnb;
  my $rrhNum;
	my ($failureEnb,$failureRrh,$noRrhEnb,$rrhIpErrEnb,$valTddRrhErrEnb,$fileErrRrh,$totalRrh) = (0,0,0,0,0,0,0);

  foreach my $enb_turn (0..@enbRows/$enbCsvWidth-1) {
    RSM::delete_ssh_known_file();

		if ( !ping(hostname=>$enbRows[$enb_turn*$enbCsvWidth+1],timeout=>3) ) {
      RSM::write_log(*MFILE,"KO! [ ENB - $enbRows[$enb_turn*$enbCsvWidth+1] ] can't ping!");
			$failureEnb++;
		  next;
		}

    if ( connect_enb( \$ssh, 
	                  $enbRows[$enb_turn*$enbCsvWidth+1],  # enb ip
	                  $enbRows[$enb_turn*$enbCsvWidth+2],  # enb user
                    $enbRows[$enb_turn*$enbCsvWidth+3]   # enb pwd
				    ) == 1 ) {
      RSM::write_log(*MFILE,"KO! [ ENB - $enbRows[$enb_turn*$enbCsvWidth+1] ] can't login!");
			$failureEnb++;
  	  sleep 1;
  	  next;
	  }

    @rrhIdPerEnb = ();
    if ( validate_tdd_rrh( \$ssh, \@splitHwType, \@rrhIdPerEnb ) ) {
      RSM::write_log(*MFILE,"KO! [ ENB - $enbRows[$enb_turn*$enbCsvWidth+1] ] not have rrhs we expect!");
      $ssh->close();
			$valTddRrhErrEnb++;
	    sleep 1;
	    next;
	  }
	  @rrhPerEnb = ();
    if ( find_rrh_ip( \$ssh , \@rrhPerEnb, \@rrhIdPerEnb ) ) {
      RSM::write_log(*MFILE,"KO! [ ENB - $enbRows[$enb_turn*$enbCsvWidth+1] ] get rrh ip error!");
      $ssh->close();
			$rrhIpErrEnb++;
	    sleep 1;
	    next;
	  }
	  $rrhNum = @rrhPerEnb;
		$totalRrh = $totalRrh + $rrhNum;
	  print "------------------- : \"$enbRows[$enb_turn*$enbCsvWidth]\" has $rrhNum RRHs!\n";
	  if ( $rrhNum == 0 ) {
      $ssh->close();
			$noRrhEnb++;
	    sleep 1;
	    next;
	  }

    ## connect to each RRH under current eNB
		# DEBUG
    #foreach ( 0..0 ) {
    foreach ( 0..$rrhNum-1 ) {
	    # print "RRH ip is : $rrhPerEnb[$_]\n";
      if ( connect_rrh( \$ssh, 
	                       $rrhPerEnb[$_],     # rrh ip
		                     ${$rrhRows[0]}[3],  # rrh login expect
		          		       ${$rrhRows[0]}[0],  # rrh login
			     		           ${$rrhRows[0]}[4],  # rrh pwd expect
		  			             ${$rrhRows[0]}[1],  # rrh pwd
				 		             ${$rrhRows[0]}[2]   # rrh command
				 		) ) {
		    my $rrhip = $rrhPerEnb[$_];
		    RSM::write_log(*MFILE,"KO! [ RRH - $rrhip ] can't login!");
				$failureRrh++;
		    sleep 1;
		    next;
		  }

      ## set trace file
		  my $date = RSM::current_time(2);
      $rrhTraceFileName = $dirs."eNB_".$enbRows[$enb_turn*$enbCsvWidth+1]."_RRH_".$rrhPerEnb[$_]."_".$date;
      open(FILE, ">$rrhTraceFileName") or do {
		    RSM::write_log(*MFILE,"KO! can't open trace file $rrhTraceFileName!");
				$fileErrRrh++;
		    next;
		  };
	    print "------------------- : start to save the trace in $rrhTraceFileName!\n";

      ## set alarmFlag which used for alarm
      $alarmFlag = 1;
      ## collect the trace in timer
      eval{
    	  alarm($enbRows[$enb_turn*$enbCsvWidth+4]);
    	  while($alarmFlag){
    	  	while(defined ($line = $ssh->read_line())){
    	   		print FILE $line."\n";
    	 	  }
	     	}
      };

      close FILE;
      $ssh->send("exit");
		  sleep 2;
			# DEBUG
			#$rrhTraceFileName = "eNB_135.242.110.169_RRH_192.168.130.1_2013_02_01";
			if ( &handle_file( $rrhTraceFileName,$dirs ) ) {
			  RSM::write_log(*MFILE,"KO! trace handle error!");
			}
			select MFILE;
			$| = 1;
			# DEBUG: print %allData, see if correct
			#foreach my $tmpKeys ( keys %allData ){
			#  print "$tmpKeys\n";
			#  foreach my $tmpChan ( keys %{$allData{$tmpKeys}} ) {
			#	  print "$tmpChan\n";
			#	  print "@{$allData{$tmpKeys}{$tmpChan}}\n";
			#	}
			#}
			&clean_up;
    }

    $ssh->close();
  }

	&connect_summary($failureEnb,$failureRrh,$noRrhEnb,$rrhIpErrEnb,$valTddRrhErrEnb,$fileErrRrh,@enbRows/$enbCsvWidth,$totalRrh);
}

###########################################################
#  sub clean_up                                           #
#    clean the data in global variable                    #
#                                                         #
#  input para:                                            #
#    no input para                                        #
#  output para:                                           #
#    no output para                                       #
#  return:                                                #
#    no return                                            #
###########################################################
sub clean_up {
  %allData = ();
  %summaryData = ();
  %allDataHist = ();
  %threshold = ();
  @patternType = ();
	@keyType = ();
}

###########################################################
#  sub handle_file                                        #
#    handle the trace file, write the issue if detect     #
#  potential problem                                      #
#                                                         #
#  input para:                                            #
#    $dataFile      - RRH trace file                      #
#    $dirs          - abs path of trace file              #
#  output para:                                           #
#    no output para                                       #
#  return:                                                #
#    0  normal return                                     #
#    1  error return                                      #
###########################################################
sub handle_file {
  my ($dataFile,$dirs) = @_;
  
  my $reportFileSuffix = "_report";
  my $reportFile = $dataFile.$reportFileSuffix;
  my $historyDatafileSuffix = "_history";
  my @splitAbsPath = split( '/', $dataFile );
  my @splitFile = split( /_/, $splitAbsPath[-1] );
  my $historyDatafile = $dirs.".".$splitAbsPath[-1].$historyDatafileSuffix;

  ## open the log file
  open(RFILE, ">$reportFile") or do {
	  return 1;
	};
  select RFILE;
  $| = 1;
  RSM::write_log(*RFILE,"Enter log file.");

  ## analyse the file, save the line with issue into report file if possible, other data will save into a data structure
  if ( &analyse( *RFILE, $dataFile, \@patternRows, \@patternType, \@keyType ) ) {
    close RFILE;
	  return 1;
	}

  ## start to analyse the data which type is non-zero
  &post_handle_data( \@patternType, *RFILE, $historyDatafile, \@splitFile );

  &analyse_summary(\%summaryData);

  RSM::write_log(*RFILE,"Exit log file.");
  close RFILE;

	# 20130321
	RSM::save_data_csv($dataFile,$txPathNum,\%allData);
	# 20130321
	return 0;
}

###########################################################
#  sub connect_summary                                    #
#    summary for this group of eNBs, calculate how many   #
#  are successful, and how many are failure connecttion   #
#                                                         #
#  input para:                                            #
#    $failureEnb      - failure connection ENBs           #
#    $failureRrh      - failure connection RRHs           #
#    $noRrhEnb        - the number of ENBs not have RRH   #
#    $rrhIpErrEnb     - the number of ENBs that RRH IP    #
#                       detect Error                      #
#    $valTddRrhErrEnb - the number of ENBs that check     #
#                       if Enb has TDD Rrh error          #
#    $fileErrRrh      - the number of RRHs that file      #
#                       open error when capture the       #
#                       specific RRH trace                #
#    $totalEnb        - total ENBs to connect             #
#    $totalRrh        - total RRHs to connect             #
#  output para:                                           #
#    no output para                                       #
#  return:                                                #
#    no return                                            #
###########################################################
sub connect_summary {
  my ($failureEnb,$failureRrh,$noRrhEnb,$rrhIpErrEnb,$valTddRrhErrEnb,$fileErrRrh,$totalEnb,$totalRrh) = @_;

  print "\n\n";
	print "SUMMARY:\n";
	print "  Total Enb                 : ",$totalEnb,"\n";
	print "    Success Enb             : ",$totalEnb-$failureEnb-$noRrhEnb-$rrhIpErrEnb-$valTddRrhErrEnb,"\n";
	print "    Conn failure Enb        : ",$failureEnb,"\n";
	print "    Not for Tdd RRH Enb     : ",$valTddRrhErrEnb,"\n";
	print "    RRH IP detect err Enb   : ",$rrhIpErrEnb,"\n";
	print "    No RRH Enb              : ",$noRrhEnb,"\n";
	print "  Total RRH                 : ",$totalRrh,"\n";
	print "    Success RRH             : ",$totalRrh-$failureRrh-$fileErrRrh,"\n";
	print "    Conn failure RRH        : ",$failureRrh,"\n";
	print "    Trace file generate err : ",$fileErrRrh,"\n";
  print "\n\n";
}

###########################################################
#  sub recv_sig_alrm                                      #
#    ALRM signal handler, set global variable $alarmFlag  #
#  to 0                                                   #
#                                                         #
#  input para:                                            #
#    no input para                                        #
#  output para:                                           #
#    no output para                                       #
#  return:                                                #
#    no return                                            #
###########################################################
sub recv_sig_alrm {
  alarm(0);
  $alarmFlag = 0;
}

########################################################
#  sub analyse_summary                                 #
#    summary the number of each pattern's issue        #
#                                                      #
#  input para:                                         #
#    $data - summary Data ref                          #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub analyse_summary {
  my $data = shift;

	print "\n";
	print "SUMMARY:\n";
	foreach ( keys %{$data} ) {
	  my $formatState = sprintf("%-40s",$_);
	  print "  $formatState : ${$data}{$_}\n";
	}
	print "\n";
}

########################################################
#  sub post_handle_data                                #
#    response to handle non-zero pattern type, it's    #
#  just a dispatcher                                   #
#                                                      #
#  input para:                                         #
#    $data - pattern type array, get from pattern.csv  #
#    $fp   - report file handler                       #
#    $histDatafile  - hist file name                   #
#    $splitFile     - data file split array ref        #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub post_handle_data {
  my ($data,$fp,$histDatafile,$splitFile) = @_;
	my $patternType1 = 1;

  my @grepData = keys %{ { map { $_ => 1 } @{$data} } };
  # print "@grepData\n";
  while( $#grepData>-1 ) {
	  my $type = shift @grepData;
	  if ( $type == $patternType1 ) {
	    &post_handle_type_1($fp,$histDatafile,$splitFile);
	  }
  }
}

########################################################
#  sub post_handle_type_1                              #
#    handle pattern type 1 data                        #
#                                                      #
#  input para:                                         #
#    $fp   - report file handler                       #
#    $histDatafile  - hist file name                   #
#    $splitFile     - data file split array ref        #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub post_handle_type_1 {
  my ($fp,$histDatafile,$splitFile) = @_;
	my @histFile;
  my $historyDatafileSuffix = "_history";

  foreach my $myKey ( keys %allData ) {
	  # print "$myKey : $allData{$myKey}\n";
	  &check_current_day_data( $allData{$myKey}, $myKey, $fp, $threshold{$myKey}[0] );
  }

  &write_history($fp,$histDatafile);
  RSM::get_hist_file_list( $splitFile, $histDayInterval, \@histFile );
  &loop_get_hist_files(\@histFile,$historyDatafileSuffix,$dirs);
  &check_hist_data($fp,\@keyType);
}

########################################################
#  sub write_history                                   #
#    save data into history file, for future usage     #
#                                                      #
#  input para:                                         #
#    $fp   - report file handler                       #
#    $histFile - history file name                     #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub write_history {
  my ($fp,$histFile) = @_;

  open(HFILE, ">$histFile") or do {
    RSM::write_log($fp,"KO! can't open history file!");
    return 1;
  };
  &write_history_file( *HFILE );
  close HFILE;
}

########################################################
#  sub occur_once                                      #
#    match log file, if pattern match, save into       #
#  report file                                         #
#                                                      #
#  input para:                                         #
#    $fp   - log file handler                          #
#    $pattern     - array of pattern type 0            #
#    $targetFp    - report file handler                #
#    $summaryData - summary data ref                   #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub occur_once {
  my ($fp,$pattern,$targetFp,$summaryData) = @_;
	${$summaryData}{${$pattern}[0]} = 0;

  while(<$fp>){
	  if ( /${$pattern}[2]/ ) {
	    print $targetFp $_; 
			${$summaryData}{${$pattern}[0]}++;
	  }
  }
}

########################################################
#  sub store_data                                      #
#    for pattern type 1, we should save data into      #
#  a hash structure first, then handle it              #
#                                                      #
#  input para:                                         #
#    $fp   - log file handler                          #
#    $pattern     - a pattern line ref                 #
#    $data - store the data from log file              #
#    $summaryData - summary data ref                   #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub store_data {
  my ($fp,$pattern,$data,$summaryData) = @_;
  my $key = ${$pattern}[3];
	# 20130321
	my $count = 0;
	my $interval;
	# 20130321

  $threshold{$key}[0] = ${$pattern}[4];
  $threshold{$key}[1] = ${$pattern}[5];
	${$summaryData}{$key} = 0;
	${$summaryData}{$key."(hist_data_cmp)"} = 0;

  while( <$fp> ) {
	  if ( /${$pattern}[2]/ ) {
	    # push @{${$data}{$key}{$1}},$2;
	    # 20130321
			if ( $count % $txPathNum == $1 ) {
	      push @{${$data}{$key}{$1}},$2;
		    $count++;
			}
			else {
			  if ( $1 > $count % $txPathNum ) {
				  $interval = $1 - $count%$txPathNum;
				  foreach (1..$interval) {
	          push @{${$data}{$key}{$count%$txPathNum+$_-1}},0;
					}
		      $count += $interval;
				}
				else {
				  $interval = $1+$txPathNum-$count%$txPathNum;
			    foreach (1..$interval) {
					  my $tmpChan = ( $count % $txPathNum + $_ > $txPathNum ) ? $count % $txPathNum + $_ - 1 - $txPathNum : $count % $txPathNum + $_ - 1;
	          push @{${$data}{$key}{$tmpChan}},0;
					}
		      $count += $interval;;
				}
	      push @{${$data}{$key}{$1}},$2;
		    $count++;
			}
	    # 20130321
	  }
  }
}

########################################################
#  sub analyse                                         #
#    analyse the trace file line by line, some alarm   #
#  can write into the log file, some will save key     #
#  data into a variable                                #
#                                                      #
#  input para:                                         #
#    $fp   - log file handler                          #
#    $analyseFile - the trace file                     #
#    $pattern     - pattern format read from csv       #
#    $type        - pattern type, get from pattern[1]  #
#    $keyType     - keyword, get from pattern[3]       #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub analyse {
  my ($fp,$analyseFile,$pattern,$type,$keyType) = @_;
	my $patternType0 = 0;
	my $patternType1 = 1;
  my $patternCsvWidth = 6;

  if ( -e $analyseFile ) {
    open(AFILE, "$analyseFile") or do {
	    RSM::write_log($fp,"KO! couldn't open the file $analyseFile!");
	    close $fp;
	    return 1;
	  };
	  foreach ( 0..@{$pattern}-1 ) {
	    push @{$type}, ${$pattern}[$_][1];
	    # print "${$pattern}[$_][0]\n";
	    seek( AFILE, 0, 0 );
      
	    if ( ${$pattern}[$_][1] == $patternType0 ) {
	      occur_once(*AFILE,${$pattern}[$_],$fp,\%summaryData);
	    }
	    elsif ( ${$pattern}[$_][1] == $patternType1 ) {
		    if ( $#{${$pattern}[$_]} == $patternCsvWidth-1 ) {
		      push @{$keyType}, ${$pattern}[$_][3];
		      store_data( *AFILE, ${$pattern}[$_], \%allData, \%summaryData, \%threshold );
		    }
		    else {
		      RSM::write_log($fp,"KO! the pattern $_ has problem, should have $patternCsvWidth items!");
		      next;
		    }
	    }
	    else {
		    RSM::write_log($fp,"KO! the pattern ${_}'s type has problem, value beyond the scope!");
	    }
	  }
	  close AFILE;
  }
  else{
	  RSM::write_log($fp,"KO! $analyseFile not exist!");
	  close $fp;
    return 1;
  }

	return 0;
}

########################################################
#  sub check_current_day_data                          #
#    check global variables within current day data    #
#                                                      #
#  input para:                                         #
#    $hashR - hash ref                                 #
#    $word  - instruction word only                    #
#    $fp    - log file handler                         #
#    $thres - threshold                                #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub check_current_day_data {
  my ($hashR,$word,$fp,$thres) = @_;
  my $TXPathId = 0;

  foreach $TXPathId (keys %{$hashR}) {
    &check_criteria(${$hashR}{$TXPathId},$word,$TXPathId,$fp,$thres);
  }
}

########################################################
#  sub format_output                                   #
#    format output the string into file                #
#                                                      #
#  input para:                                         #
#    $state - statement before the data, only          #
#             instruction                              #
#    $data  - the data that saved in the log file      #
#    $fh    - log file handler                         #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub format_output {
  my ($state,$data,$fh) = @_;

  my $format_state = sprintf("%-50s",$state);
  if ( ref($data) eq "SCALAR" ) {
	  print $fh "$format_state : ${$data}\n";
  }
  elsif ( ref($data) eq "ARRAY" ) {
	  print $fh "$format_state : @{$data}\n";
  }
}

########################################################
#  sub check_criteria                                  #
#    check each data, find the max and min of them,    #
#  if diff is larger than threshold, it will save into #
#  log file.                                           #
#                                                      #
#  input para:                                         #
#    $data    - the data which used for compare        #
#               with threshold                         #
#    $word    - sth saved in log file, only for        #
#               instruction                            #
#    $channel - channel number in all TX path          #
#    $fh      - log file handler                       #
#    $threshold - threshold                            #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub check_criteria {
  my ($data, $word, $channel, $fh, $threshold) = @_;
  my ($statement, $value);

  # print "@{$data}\n";
  # print "$threshold\n";
  my $c_max = max @{$data};
  my $c_min = min @{$data};
  if ( $c_max - $c_min >= $threshold ) {
	  $statement = "For $word, Channel $channel";
	  $value = "difference is larger than ${threshold}db";
    format_output( $statement, \$value, $fh );
		$summaryData{$word}++;
  }
}

########################################################
#  sub write_history_file                              #
#    write the data into history file based on format  #
#                                                      #
#  input para:                                         #
#    $fp - the history log file handler                #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub write_history_file {
  my ($fp) = @_;

  foreach my $myKey (keys %allData){
	  # print "$myKey : $allData{$myKey}\n";
	  RSM::write_history_file_block( $allData{$myKey}, $myKey, \%allDataHist, $fp );
	  print $fp "\n";
  }
}

########################################################
#  sub loop_get_hist_files                             #
#    open all hist files of $data one by one, read     #
#  its data                                            #
#                                                      #
#  input para:                                         #
#    $data - data ref                                  #
#    $histDatafileSuffix - the suffix of hist file     #
#    $dir  - absolute path                             #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub loop_get_hist_files {
  my ($data, $histDatafileSuffix, $dir) = @_;

  foreach my $fileSeq ( 0..@{$data}-1 ) {
    my $wholeFile = $dir.${$data}[$fileSeq].$histDatafileSuffix;

    # print "$wholeFile\n";
    if ( -e $wholeFile ) {
      &get_single_hist_file( $wholeFile );
    }
  }
}

########################################################
#  sub get_single_hist_file                            #
#    open the single hist file, read its data, saved   #
#  in a global variable                                #
#                                                      #
#  input para:                                         #
#    $file  - the hist file                            #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub get_single_hist_file {
  my ($file) = @_;
  my $key;

  open(HFILE, "$file") or do {
	  # print "couldn't open the file : $file\n";
		return 1;
	};

  while(<HFILE>) {
	  chomp($_);

	  if ( /\[(.*)\]/ ) {
	    $key = $1; 
	  }
	  elsif ( /\d+:(\d+.\d+)/ ) {
	    my @tmp_hist_data = split( /:/, $_ );
	    push @{$allDataHist{$key}{$tmp_hist_data[0]}}, $tmp_hist_data[-1];
	  }
  }

  close HFILE;
}

########################################################
#  sub check_hist_data                                 #
#    check hist data, write data into log file         #
#                                                      #
#  input para:                                         #
#    $fp - report file handler                         #
#    $keyType - key word ref get from pattern          #
#  output para:                                        #
#    no output para                                    #
#  return:                                             #
#    no return                                         #
########################################################
sub check_hist_data {
  my ($fp,$keyType) = @_;
  my @tmpArr;
  my %trans = map { $_ => 1 } @{$keyType};

  foreach my $keyWord ( keys %allDataHist ) {
	  if ( exists( $trans{$keyWord} ) ) {
	    foreach (keys %{$allDataHist{$keyWord}}) {
        check_criteria($allDataHist{$keyWord}{$_},$keyWord."(hist_data_cmp)",$_,$fp,$threshold{$keyWord}[1]);
	    }
    
	    foreach (keys %{$allDataHist{$keyWord}}) {
	      @tmpArr = reverse @{$allDataHist{$keyWord}{$_}};
        format_output( uc($keyWord)." HIST DATA, Channel $_", \@tmpArr, $fp );
	    }
	  }
  }
}

__END__

20130320   modify validate tdd rrh function, loop check 1100-6100 directory instead of only 2100
20130321   add function, save data with type 1 into csv file, it's easy for user to see the data by graph in excel
