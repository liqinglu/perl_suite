#/usr/bin/perl -w

package RSM;

use strict;
use warnings;
use Text::CSV;
use Date::ICal;
use Date::Leapyear;
use Array::Average;
use Net::FTP;
use XML::Simple;
use Net::Telnet;
use Net::SSH::Expect;
#use Net::SFTP;
use Net::SFTP::Foreign;

my ( @enbKeyField, @groupKeyField, @rrhKeyField, @alarmKeyField, @samKeyField, @patternKeyField, @cgiKeyField );

######################################################
#  sub init                                          #
#    init arrays                                     #
#                                                    #
#  input para:                                       #
#    no input para                                   #
#  output para:                                      #
#    no output para                                  #
#  return:                                           #
#    no return                                       #
######################################################
sub init {
  @enbKeyField = qw(enb_id enb_ip enb_login enb_pass trace_collection_period);
  @groupKeyField = qw(group_size enb_default_login enb_default_pwd period rrh_hwtype);
  @rrhKeyField = qw(rrh_login rrh_pass rrh_cmd rrh_login_expect rrh_pass_expect);
	@alarmKeyField = qw(hist_day_interval tx_path clean_day_interval log_size);
	@samKeyField = qw(samip user pwd dir prompt);
	@patternKeyField = qw(name type pattern key threshold hist_threshold);
	@cgiKeyField = qw(app_path);
}

######################################################
#  sub get_field                                     #
#    get array based on input para                   #
#                                                    #
#  input para:                                       #
#    $option - could be 1/2/3/4/5/6                  #
#  output para:                                      #
#    no output para                                  #
#  return:                                           #
#    return @enbKeyField if $option = 1              #
#    return @groupKeyField if $option = 2            #
#    return @rrhKeyField if $option = 3              #
#    return @alarmKeyField if $option = 4            #
#    return @samKeyField if $option = 5              #
#    return @patternKeyField if $option = 6          #
#    return @cgiKeyField if $option = 7              #
######################################################
sub get_field {
  my $option = shift;

  if ( $option == 1 ) {
    return @enbKeyField;
  }
  elsif ( $option == 2 ) {
    return @groupKeyField;
  }
  elsif ( $option == 3 ) {
    return @rrhKeyField;
  }
	elsif ( $option == 4 ) {
	  return @alarmKeyField;
	}
	elsif ( $option == 5 ) {
	  return @samKeyField;
	}
	elsif ( $option == 6 ) {
	  return @patternKeyField;
	}
	elsif ( $option == 7 ) {
	  return @cgiKeyField;
	}
}

######################################################
#  sub read_csv                                      #
#    read content from csv file                      #
#                                                    #
#  input para:                                       #
#    $filename - csv file name                       #
#    $dirs - absolute path                           #
#    $rows - the data ref                            #
#    $option - the indication of the array           #
#  output para:                                      #
#    $rows - the content of file                     #
#  return:                                           #
#    0 : normal return                               #
#    1 : error return                                #
######################################################
sub read_csv {
  my $filename = shift;
  my $dirs = shift;
  my $rows = shift;
	my $option = shift;

  my $row;
  my $count = 0;
	my @keyField;

  init();
  my $csv = Text::CSV->new ( { binary => 1 } )
    or do {
		  return 1;
		};
  my $file = $dirs.$filename;
	# print "$file\n";
  open my $fh, "<:encoding(utf8)", "$file" or do {
	  return 1;
	};
  while ( $row = $csv->getline( $fh ) ) {
	  next if ( ${$row}[0] =~ /^#(.*)/ ); 
		next if ( ${$row}[0] =~ /^$/ );
    push @{ ${$rows}[ $count++ ] } , @{$row} ;
  }
  $csv->eof or $csv->error_diag();
  close $fh;

  @keyField = get_field($option);
	if ( validate( ${$rows}[0], \@keyField ) ) {
	  return 1;
	}

  shift @{$rows};
	if ( $#{$rows} == -1 ) {
	  return 1;
	}

	return 0;
}

######################################################
#  sub validate                                      #
#    validate two arrays if equal                    #
#                                                    #
#  input para:                                       #
#    $first  - the first array ref to be checked     #
#    $std    - the standard array ref                #
#  output para:                                      #
#    no output para                                  #
#  return:                                           #
#    0 : equal                                       #
#    1 : not equal                                   #
######################################################
sub validate {
  my ($first, $std) = @_;
  my $lower_case_str;

  $lower_case_str = lc( join('_',@{$first}));
  if ( $lower_case_str eq join( '_',@{$std} ) ) {
    return 0;  # validate success 
  }
  else {  
    return 1;  # validate KO
  }
}

######################################################
#  sub delete_ssh_known_file                         #
#    delete ssh known file which locate in           #
#  $HOME/.ssh/known_file, guarentee every time ssh   #
#  connection is successful                          #
#                                                    #
#  input para:                                       #
#    no input para                                   #
#  output para:                                      #
#    no output para                                  #
#  return:                                           #
#    no return                                       #
######################################################
sub delete_ssh_known_file {
  my $home_path = $ENV{"HOME"};
  my $know_file = $home_path."/.ssh/known_hosts";
		  
  unlink $know_file;
}

######################################################
#  sub filter_group                                  #
#    find all rrhs which belongs to the grouped enb  #
#                                                    #
#  input para:                                       #
#    $enb       - enb group ref                      #
#    $rrh       - rrh ref                            #
#    $enbSize   - the number of items in enb.csv     #
#    $filterRrh - filter rrh ref, contains all rrhs  #
#                 that belongs to $enb group         #
#  output para:                                      #
#    $filterRrh - filter rrh ref                     #
#  return:                                           #
#    no return                                       #
######################################################
sub filter_group {
  my ($enb,$rrh,$enbSize,$filterRrh) = @_;
  my @enb_group_include;

  foreach (0..@{$enb}/$enbSize-1) {
    push @enb_group_include, ${$enb}[$_*$enbSize];
  }

  foreach my $rrh_count (0..@{$rrh}-1) {
    if ( my @grep_group = grep { $_ eq @{${$rrh}[$rrh_count]}[0] } @enb_group_include ) {
      push @{ ${$filterRrh}{ @{${$rrh}[$rrh_count]}[0] } }, @{${$rrh}[$rrh_count]};
    }
  }
}

######################################################
#  sub current_time                                  #
#    get formatted time                              #
#                                                    #
#  input para:                                       #
#    $option - could be 1/2                          #
#  output para:                                      #
#    no output para                                  #
#  return:                                           #
#    return "yyyymmddhhmmss" if $option = 1          #
#    return "yyyymmdd" if $option = 2                #
######################################################
sub current_time {
  my $option = shift;
  my $connect_time;

  my ($sec,$min,$hour,$day,$mon,$year,$wday,$yday,$isdst)=localtime();
  $year+= 1900;
  $mon+= 1;

  if ( $option == 1 ) {
    $connect_time = sprintf("%04d_%02d_%02d_%02d_%02d_%02d",$year,$mon,$day,$hour,$min,$sec);
    return $connect_time;
  }
  else {  
    $connect_time = sprintf("%04d_%02d_%02d",$year,$mon,$day);
    return $connect_time;
  }
}

######################################################
#  sub call_handlefile                               #
#    call handlefile.pl                              #
#                                                    #
#  input para:                                       #
#    $cmd - the command with absolute path           #
#    $filename - the file to be handled              #
#  output para:                                      #
#    no output para                                  #
#  return:                                           #
#    0 : normal return                               #
#    1 : error return                                #
######################################################
sub call_handlefile {
  my ($cmd,$fileName) = @_;

  defined(my $pid = fork) or do {
	  return 1;
	};
  unless($pid){
    my $cmd = "perl $cmd $fileName";
    exec $cmd;
  }
	
	return 0;
}

######################################################
#  sub call_monitor                                  #
#    call monitor.pl                                 #
#                                                    #
#  input para:                                       #
#    $cmd - the command with absolute path           #
#    $groupId - the group ID                         #
#    @data - enb data get from enb.csv               #
#  output para:                                      #
#    no output para                                  #
#  return:                                           #
#    0 : normal return                               #
#    1 : error return                                #
######################################################
sub call_monitor {
  my $cmd = shift;
  my $groupId = shift;
  my @data = @_;
  #my $data = shift;

  defined(my $pid = fork) or do { 
    return 1; 
  };
  unless ($pid) {
    my $cmd = "perl $cmd $groupId @data"; 
    exec $cmd;
  }

	return 0;
}

######################################################
#  sub get_hist_file_list                            #
#    get formatted time                              #
#                                                    #
#  input para:                                       #
#    $split - split array of log file                #
#    $interval - day interval of history             #
#    $hist - hist file ref                           #
#  output para:                                      #
#    $hist - the array of hist file                  #
#  return:                                           #
#    no return                                       #
######################################################
sub get_hist_file_list {
  my ( $split, $interval, $hist ) = @_; 
  my $day = ${$split}[-1];
  my $month = ${$split}[-2];
  my $year = ${$split}[-3];

  my $ical = Date::ICal->new( year => $year, month => $month, day => $day, offset => '+0000');
  foreach ( 1..$interval-1 ) {
    $ical->add( day => -1 );
    ${$split}[-1] = sprintf( "%02d", $ical->day );
    ${$split}[-2] = sprintf( "%02d", $ical->month );
    ${$split}[-3] = $ical->year;
    my $new_file_name = ".".join('_',@{$split});
    push( @{$hist}, $new_file_name );
  }
}

######################################################
#  sub write_history_file_block                      #
#    write history file block                        #
#                                                    #
#  input para:                                       #
#    $data - hash data ref                           #
#    $comment - an instruction words                 #
#    $data_hist - hash hist data ref                 #
#    $fh - history file handler                      #
#  output para:                                      #
#    no output para                                  #
#  return:                                           #
#    0 : normal return                               #
#    1 : error return                                #
######################################################
sub write_history_file_block {
  my ($data,$comment,$data_hist,$fh) = @_;

  print $fh "[$comment]\n";

	if ( !%{$data} ) {
	  return 1;
	}

  foreach my $channel (keys %{$data}) {
    my $p_avg = average ( @{${$data}{$channel}} );
    print $fh "$channel:$p_avg\n";
    push @{${$data_hist}{$comment}{$channel}}, $p_avg;
  }
	
	return 0;
}

######################################################
#  sub write_log                                     #
#    write log file, including main log file,        #
#  monitor log file and trace analyse log file.      #
#                                                    #
#  input para:                                       #
#    $file  - log file handler                       #
#    $state - statement write into log file          #
#  output para:                                      #
#    no output para                                  #
#  return:                                           #
#    no return                                       #
######################################################
sub write_log {
  my ($file,$state) = @_;
  my $time = current_time(1);

  print $file $time." : ".$state."\n";
}

##############################################
#  sub parse_xml                             #
#    parse xml file, meanwhile, save those   #
#  infos into enb.csv                        #
#                                            #
#  input para:                               #
#    $file  - enb.csv file                   #
#    $samRowsR - the array ref, content      #
#                read from samconf.csv       #
#    $sp    - ARGV[0] split array ref        #
#    $group - include login info ref         #
#  output para:                              #
#    no output para                          #
#  return:                                   #
#    no return                               #
##############################################
sub parse_xml {
  my ( $dirs, $file, $samRowsR, $sp, $group )  = @_;
	my ( @writeCsv, $config );
	my $site = "siteId";
	my $enbIp = "ipAddress";
	my $wholeFile = $dirs.$file;

  open(FILE,">$wholeFile") or die "Couldn't open the enb.csv!\n";
  my @keyField = RSM::get_field(1);
  print FILE join(',',@keyField)."\n";

  foreach (0..@{$samRowsR}-1) {
  	my $checkFile = ${$sp}[0].$_.".".${$sp}[1];
    if ( -e $checkFile ) {
	  	$config = XMLin($checkFile);
	  	my $fixedPath = $config->{"SOAP:Body"}->{findResponse}->{result}->{"netw.NetworkElement"};
			if( ref $fixedPath eq "ARRAY" ){
	  	  foreach my $arrId ( @{$fixedPath} ) {
	  	    foreach ( keys %{$arrId} ) {
	  		    if ( $_ eq $site ) {
				  	  if ( @writeCsv != 1 ) {
	  		  	    push @writeCsv,${$arrId}{$_};
				  		}
				  		else {
	  		  	    unshift @writeCsv,${$arrId}{$_};
				  		}
	  		  	}
	  		  	elsif ( $_ eq $enbIp ) {
	  		  	  push @writeCsv,${$arrId}{$_};
	  		  	}
	  		  	else {
	  		  	  print "------------------- : xml parser error, exit!\n";
	  		  		close FILE;
	  		  		exit 1;
	  		  	}
	  		  }
	  		  push @writeCsv,${${$group}[0]}[1];
	    		push @writeCsv,${${$group}[0]}[2];
	    		push @writeCsv,${${$group}[0]}[3];

          print FILE join(',',@writeCsv)."\n";
		    	@writeCsv = ();
		    }
			}
			elsif ( ref $fixedPath eq "HASH" ){
	  	    foreach ( keys %{$fixedPath} ) {
	  		    if ( $_ eq $site ) {
				  	  if ( @writeCsv != 1 ) {
	  		  	    push @writeCsv,${$fixedPath}{$_};
				  		}
				  		else {
	  		  	    unshift @writeCsv,${$fixedPath}{$_};
				  		}
	  		  	}
	  		  	elsif ( $_ eq $enbIp ) {
	  		  	  push @writeCsv,${$fixedPath}{$_};
	  		  	}
	  		  	else {
	  		  	  print "------------------- : xml parser error, exit!\n";
	  		  		close FILE;
	  		  		exit 1;
	  		  	}
	  		  }
	  		  push @writeCsv,${${$group}[0]}[1];
	    		push @writeCsv,${${$group}[0]}[2];
	    		push @writeCsv,${${$group}[0]}[3];

          print FILE join(',',@writeCsv)."\n";
		    	@writeCsv = ();
			}
    }
  }

  close FILE;
}

##############################################
#  sub get_file                              #
#    ftp to sam server to get xml file       #
#                                            #
#  input para:                               #
#    $sp   - file split array ref            #
#    $rows - include login info ref          #
#    $file - the file we should get          #
#  output para:                              #
#    no output para                          #
#  return:                                   #
#    no return                               #
##############################################
sub get_file {
  my ( $sp,$rows,$file ) = @_;
  my $ftp;
  
	foreach (0..@{$rows}-1) {
	  $ftp = Net::SFTP::Foreign->new( ${${$rows}[$_]}[0], user=>${${$rows}[$_]}[1] , password=>${${$rows}[$_]}[2] )
		  or die "Can not connect to the host: $@";
		$ftp->setcwd( ${${$rows}[$_]}[3] ) or die "setcwd failed\n";
	  my $getFile = ${$sp}[0].$_.".".${$sp}[1];
		$ftp->get( $file, $getFile ) or die "get failed\n";
		$ftp->disconnect;
	}
}

##############################################
#  sub generate_file                         #
#    telnet to sam server, exec SAMO cmd,    #
#  generate output xml file                  #
#                                            #
#  input para:                               #
#    $result   - output xml file             #
#    $request  - script xml file             #
#    $samData  - data read from conf file    #
#  output para:                              #
#    no output para                          #
#  return:                                   #
#    no return                               #
##############################################
sub generate_file {
  my ($result,$request,$samData) = @_;
	my $mycmd;
	my $mark;
	my $sshRes;

  foreach (0..@{$samData}-1) {
	  $mark = ${${$samData}[$_]}[4];

		my $samSsh = Net::SSH::Expect->new (
		  host => "${${$samData}[$_]}[0]",
			user => "${${$samData}[$_]}[1]",
			password => "${${$samData}[$_]}[2]",
			raw_pty => 1
		);
		$sshRes = $samSsh->login() or die "SSH login fail\n";
	  $mycmd = "cd ${${$samData}[$_]}[3]";
	  $sshRes = $samSsh->exec($mycmd);
	  $mycmd = "/bin/rm -f $result";
	  $sshRes = $samSsh->exec($mycmd);
	  $mycmd = "cd ..";
	  $sshRes = $samSsh->exec($mycmd);
	  $mycmd = "./postxmlstream.bin scripts/$request > output/$result";
	  $sshRes = $samSsh->exec($mycmd);
		$samSsh->close();

		## below is telnet, it's out of time
	  #my $telnet=new Net::Telnet(
	  #  Timeout=>20,
	  #  Prompt=>"/$mark/"
	  #);
	  #$telnet->open( ${${$samData}[$_]}[0] );
	  #$telnet->login( ${${$samData}[$_]}[1], ${${$samData}[$_]}[2] );
	  #$mycmd = "cd ${${$samData}[$_]}[3]";
	  #$telnet->cmd($mycmd);
	  #$mycmd = "/bin/rm -f $result";
	  #$telnet->cmd($mycmd);
	  #$mycmd = "cd ..";
	  #$telnet->cmd($mycmd);
	  #$mycmd = "./postxmlstream.bin scripts/$request > output/$result";
	  #$telnet->cmd($mycmd);
	  #$telnet->close;
	}
}

##############################################
#  sub save_data_csv                         #
#    telnet to sam server, exec SAMO cmd,    #
#  generate output xml file                  #
#                                            #
#  input para:                               #
#    $dataFile - trace file name             #
#    $txNum  - TX channel number             #
#    $data   - data ref                      #
#  output para:                              #
#    no output para                          #
#  return:                                   #
#    0 normal return                         #
#    1 error return                          #
##############################################
sub save_data_csv {
  my ($dataFile,$txNum,$data) = @_;
	my @sDate;
	my $wCsvFile;

  return unless ( %{$data} );

	my @fileName = split('/',$dataFile);
	my @sFile = split('_',$fileName[-1]);
	#print "@sFile\n";
	foreach (1..3) {
	  unshift @sDate, pop @sFile;
	}
	#print join('_',@sDate),"\n";
	#print join('_',@sFile),"\n";

	my $csvFile = join('_',@sFile)."_data.csv";
	pop @fileName;
	my $absPath = join('/',@fileName);
	$wCsvFile = $absPath.'/'.$csvFile;
	if ( -e $wCsvFile ) {
		if ( append_csv($wCsvFile,join('_',@sDate),$data,$txNum) ) {
		  return 1;
		}
	}
	else {
		if ( write_new_csv($wCsvFile,join('_',@sDate),$data,$txNum) ) {
		  return 1;
		}
	}

	return 0;
}

##############################################
#  sub find_length                           #
#    find the largest length of the data,    #
#  data format is HASH-HASH-ARRAY, so the    #
#  array length of each HASH is what we      #
#  measure here                              #
#                                            #
#  input para:                               #
#    $data    - data to be measured length   #
#  output para:                              #
#    no output para                          #
#  return:                                   #
#    no return                               #
##############################################
sub find_length {
  my $data = shift;
	my $len = 0;

	foreach my $outterKey ( keys %{$data} ) {
	  foreach my $innerKey ( keys %{${$data}{$outterKey}} ) {
		  if ( @{${$data}{$outterKey}{$innerKey}} > $len ) {
			  $len = @{${$data}{$outterKey}{$innerKey}};
			}
		}
	}

	return $len;
}

##############################################
#  sub write_data                            #
#    write data into the file based on       #
#  format                                    #
#                                            #
#  input para:                               #
#    $fp      - csv file handler             #
#    $arrLength - the largest arr length of  #
#                 the data                   #
#    $data    - data that write into csv     #
#    $txNum   - TX channel number            #
#    $cDate   - current date                 #
#  output para:                              #
#    no output para                          #
#  return:                                   #
#    no return                               #
##############################################
sub write_data {
  my ($fp,$arrLength,$data,$txNum,$cDate) = @_;
	my @myKeys;
	my @tmpKeys;

  # return unless ( %{$data} );
  print $fp ",";
	foreach (sort keys %{$data}) {
	  push @myKeys, $_;
	  print $fp $_;
		foreach (1..$txNum) {
      print $fp ",";
		}
	}
	print $fp "\n";
  print $fp "$cDate,";
	foreach (keys %{$data}) {
		foreach (0..$txNum-1) {
      print $fp $_;
      print $fp ",";
		}
	}
	print $fp "\n";
  print $fp ",";

  ## print only average of each channel
  foreach my $turns ( sort keys %{$data} ) {
	  foreach ( 0..$txNum-1 ) {
		  my $p_avg = average ( @{${$data}{$turns}{$_}} );
			print $fp $p_avg;
			print $fp ",";
		}
	}
	print $fp "\n";

  ## print all of %allData
  #foreach my $turns (0..$arrLength-1) {
	#  print $fp "," if ($turns!=0);
	#  @tmpKeys = @myKeys;
	#  while(@tmpKeys) {
	#    my $this = shift @tmpKeys;
  #    foreach ( 0..$txNum-1 ) {
	#		  # print "@{${$data}{$this}{$_}}\n";
	#  	  if ( @{${$data}{$this}{$_}} ) {
	#  	    print $fp shift @{${$data}{$this}{$_}};
	#  			print $fp ",";
	#  		}
	#  		else {
	#  		  print $fp ",";
	#  		}
	#  	}
	#  }
	#	print $fp "\n";
	#}
}

##############################################
#  sub write_new_csv                         #
#    write a new csv file                    #
#                                            #
#  input para:                               #
#    $csvFile - csv file for the RRH         #
#    $cDate   - current date                 #
#    $data    - data that write into csv     #
#    $txNum   - TX channel number            #
#  output para:                              #
#    no output para                          #
#  return:                                   #
#    0 normal return                         #
#    1 error return                          #
##############################################
sub write_new_csv {
  my ($csvFile,$cDate,$data,$txNum) = @_;

  my $arrLength = find_length($data);

  open(DFILE,">$csvFile") or do { return 1; };
	write_data(*DFILE,$arrLength,$data,$txNum,$cDate);

	close DFILE;
  return 0;
}

##############################################
#  sub append_csv                            #
#    append the data to a existing csv file  #
#                                            #
#  input para:                               #
#    $csvFile - csv file for the RRH         #
#    $cDate   - current date                 #
#    $data    - data that write into csv     #
#    $txNum   - TX channel number            #
#  output para:                              #
#    no output para                          #
#  return:                                   #
#    0 normal return                         #
#    1 error return                          #
##############################################
sub append_csv {
  my ($csvFile,$cDate,$data,$txNum) = @_;

  my $arrLength = find_length($data);

  open(DFILE,">>$csvFile") or do { return 1; };
	write_data(*DFILE,$arrLength,$data,$txNum,$cDate);

	close DFILE;
  return 0;
}

1;


__END__

20130917 change telnet to SSH when login to SAM, also for ftp way, modify function generate_file and get_file
