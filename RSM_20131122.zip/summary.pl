#/usr/bin/perl -w

use strict;
use warnings;
use File::Spec;
use HTML::Stream;
use HTML::Template;

=head1 PROGRAM DESCRIPTION

  summary all current day report files, save those information into html format, default html file name is index.html 

=cut

my $pathCurf = File::Spec->rel2abs(__FILE__);
my ($vol, $dirs, $file) = File::Spec->splitpath($pathCurf);
unshift @INC,$dirs;
require "RSM.pm";

my $summaryLog = $dirs.".summary.log";
my $patternConf = "pattern.csv";
my $alarmConf = "alarm.csv";
my $searchSuffix = "_report";
my %summaryData = ();
my %enbSort;
my %rrhSort;
my @summaryItems;
my @patternRows;
my @alarmRows;
my $updateIndexFlag;
my $span;

=head1 FUNC get_hist_list

  sub get_hist_list
    get history file list within $interval days

=cut

sub get_hist_list {
  my ( $current, $interval, $hist ) = @_; 
	my @split = split('_',$current);
  my $day = $split[-1];
  my $month = $split[-2];
  my $year = $split[-3];

  push( @{$hist}, $current );
  my $ical = Date::ICal->new( year => $year, month => $month, day => $day, offset => '+0000');
  foreach ( 1..$interval-1 ) {
    $ical->add( day => -1 );
    $split[-1] = sprintf( "%02d", $ical->day );
    $split[-2] = sprintf( "%02d", $ical->month );
    $split[-3] = $ical->year;
    my $new_file_name = join('_',@split);
    push( @{$hist}, $new_file_name );
  }
}

=head1 FUNC find_pattern_number

  sub find_pattern_number
    find how many items in summary, for type 0, only one item; 
  for type 1, there are two items to summary, because one is for current day, another is for historic summary

  return
    return total items which displayed in summary

=cut

sub find_pattern_number {
  my $data = shift;
	my $count = 0;
	my $countConst = 3;

	foreach (0..@{$data}-1) {
	  if ( ${$data}[$_][1] == 0 ) {
		  $count += 1;
		}
		elsif ( ${$data}[$_][1] == 1 ) {
		  $count += 2;
		}
	}

	return $countConst+$count;
}

=head1 FUNC sort_enb_rrh

  sub sort_enb_rrh
    summary the total issue number for each ENB and each RRH, save in a hash structure

=cut

sub sort_enb_rrh {
  my ($data,$enb,$rrh) = @_;
	my ($enbCount,$rrhCount) = 0;

	foreach my $kenb (keys %{$data}) {
	  foreach my $krrh (keys %{${$data}{$kenb}}) {
		  foreach my $kitems (keys %{${$data}{$kenb}{$krrh}}) {
			  $rrhCount += ${$data}{$kenb}{$krrh}{$kitems};
				$enbCount += ${$data}{$kenb}{$krrh}{$kitems};
			}
			${$rrh}{$kenb}{$krrh} = $rrhCount;
			$rrhCount = 0;
		}
	  ${$enb}{$kenb} = $enbCount;
		$enbCount = 0;
	}
}

=head1 FUNC save_summary_data

  sub save_summary_data
    find all report files in the directory, analyse "SUMMARY" part to get every data for each RRH,
  save all those data into a HASH structure

=cut

sub save_summary_data {
  my ($dirs,$cTime,$searchSuffix,$patternItems,$data,$items) = @_;
	my @splitFile;
	my @splitAbsFile;
	my $i = 0;

  my @fileList = qx/ls $dirs*$cTime$searchSuffix/;
  foreach (@fileList) {
	  #@splitFile = split('_',$_);
	  @splitAbsFile = split('/',$_);
		@splitFile = split('_',$splitAbsFile[-1]);
    my @tailResult = qx/tail -$patternItems $_/;
	  next unless $tailResult[0] =~ /SUMMARY/;
	  #print "@tailResult\n";

    shift @tailResult;
		pop @tailResult;
		pop @tailResult;
	  foreach my $perLine (@tailResult) {
		  chomp($perLine);
			#print "$perLine\n";
			if ( $perLine =~ /^\s+(\w+\(\w+\))\s+:\s+(\d+)/ || $perLine =~ /^\s+(\w+)\s+:\s+(\d+)/ ) {
			  #print "$1 : $2\n";
				${$data}{$splitFile[1]}{$splitFile[3]}{$1} = $2;
				if ( $i == 0 ){  # if first time, save all alarm threshold type into a list
				  push @{$items}, $1;
				}
			}
	  }
		$i++;
		#print "\n";
  }
}

=head1 FUNC make_html

  sub make_html
    make a new index.html based on the data we figure out a moment ago

=cut

sub make_html {
  my ($file,$data,$fp,$items,$enb,$rrh,$cTime) = @_;
  my $HTML;
	my $c0Thres = 5;
	my $c1Thres = 3;
	my $c2Thres = 1;
	my $c3Thres = 0;
	
	open(FILE,">$file") or do {
	  RSM::write_log($fp,"KO! open html file failure!");
		exit 1;
	};

	$HTML = new HTML::Stream \*FILE;

      # The vanilla interface...
			$HTML->tag('html');
			$HTML->nl;
			$HTML->tag('head');
			$HTML->nl;
			#$HTML->tag('meta', http-equiv=>"Content-Type", content=>"text/html; charset=utf-8");
			#$HTML->tag('_meta');
			#$HTML->nl;
			#$HTML->tag('meta', http-equiv=>"Content-Language", content=>"en-us");
			#$HTML->tag('_meta');
			#$HTML->nl;
			$HTML->tag('link', rel=>"stylesheet", type=>"text/css", href=>"cover.css");
			$HTML->tag('_link');
			$HTML->nl;
			$HTML->tag('title');
      $HTML->text("Daily Report");
			$HTML->tag('_title');
			$HTML->nl;
			$HTML->tag('_head');
			$HTML->nl;

			$HTML->tag('body');
			$HTML->nl;
			$HTML->tag('h1');
      $HTML->text("Daily Report");
			$HTML->tag('_h1');
			$HTML->nl;
			$HTML->tag('table');
			$HTML->nl;
			$HTML->tag('tr');
			$HTML->tag('td', class=>"h", align=>"right");
      $HTML->text("ReportDate:");
			$HTML->tag('_td');
			$HTML->tag('td', align=>"left", colspan=>"4");
			my $cDate = RSM::current_time(1);
      $HTML->text($cDate);
			$HTML->tag('_td');
			$HTML->tag('_tr');
			$HTML->nl;
			$HTML->tag('tr');
			$HTML->tag('td', class=>"h", align=>"right");
      $HTML->text("Perl Version:");
			$HTML->tag('_td');
			$HTML->tag('td', align=>"left", colspan=>"4");
      $HTML->text("v5.14.1");
			$HTML->tag('_td');
			$HTML->tag('_tr');
			$HTML->nl;
			$HTML->tag('tr');
			$HTML->tag('td', class=>"h", align=>"right");
      $HTML->text("OS:");
			$HTML->tag('_td');
			$HTML->tag('td', align=>"left", colspan=>"4");
      $HTML->text("linux");
			$HTML->tag('_td');
			$HTML->tag('_tr');
			$HTML->nl;
			$HTML->tag('tr');
			$HTML->nl;
			$HTML->tag('td', class=>"h", align=>"right");
      $HTML->text("Thresholds:");
			$HTML->tag('_td');
			$HTML->nl;
			$HTML->tag('td', class=>"c0");
      $HTML->text(">=5");
			$HTML->tag('_td');
			$HTML->tag('td', class=>"c1");
      $HTML->text(">=3");
			$HTML->tag('_td');
			$HTML->tag('td', class=>"c2");
      $HTML->text(">=1");
			$HTML->tag('_td');
			$HTML->tag('td', class=>"c3");
      $HTML->text("= 0");
			$HTML->tag('_td');
			$HTML->nl;
			$HTML->tag('_tr');
			$HTML->nl;
			$HTML->tag('_table');
			$HTML->nl;

			$HTML->tag('div');
			$HTML->tag('br/');
			$HTML->tag('_div');
			$HTML->nl;

      #########################
			$HTML->tag('FORM',METHOD=>"GET",ACTION=>"http://localhost/cgi-bin/enb_hist_query.pl");
			$HTML->nl;
			$HTML->tag('p');
			$HTML->text("I want to query enb history data : ");
			$HTML->tag('input',name=>"enbip", size=>15);
			$HTML->nl;
			$HTML->tag('input',type=>"submit",value=>"submit");
			$HTML->tag('input',type=>"reset",value=>"reset");
			$HTML->nl;
			$HTML->tag('_FORM');
			$HTML->nl;
			#########################

			$HTML->tag('div');
			$HTML->tag('br/');
			$HTML->tag('_div');
			$HTML->nl;

			$HTML->tag('table');
			$HTML->nl;
			$HTML->tag('tr');
			$HTML->tag('td', class=>"h");
			$HTML->text("ENB");
			$HTML->tag('_td');
			$HTML->tag('td', class=>"h");
			$HTML->text("Total Issue");
			$HTML->tag('_td');
			$HTML->tag('td', class=>"h");
			$HTML->text("RRH");
			$HTML->tag('_td');
			$HTML->tag('td', class=>"h");
			$HTML->text("RRH Issue");
			$HTML->tag('_td');
			foreach (sort @{$items}) {
			  $HTML->tag('td', class=>"h");
			  $HTML->text($_);
			  $HTML->tag('_td');
			}
			$HTML->tag('td', class=>"h");
			$HTML->text("Raw Trace");
			$HTML->tag('_td');
			$HTML->tag('_tr');
			$HTML->nl;
			my $cenb = "undef";
			foreach my $kenb ( sort { ${$enb}{$b} <=> ${$enb}{$a} } keys %{$enb} ) {
			  foreach my $krrh ( sort { ${$rrh}{$kenb}{$b} <=> ${$rrh}{$kenb}{$a} } keys %{${$rrh}{$kenb}} ) {
				  if ( $cenb eq $kenb ) {
			      $HTML->tag('tr');
			      $HTML->tag('td');
			      $HTML->tag('_td');
			      $HTML->tag('td');
			      $HTML->tag('_td');
					}
					else {
			      $HTML->tag('tr');
			      $HTML->tag('td');
			      $HTML->text($kenb);
			      $HTML->tag('_td');
			      $HTML->tag('td');
			      $HTML->text( ${$enb}{$kenb} );
			      $HTML->tag('_td');

						$cenb = $kenb;
					}
			    $HTML->tag('td');
			    $HTML->text($krrh);
			    $HTML->tag('_td');
			    $HTML->tag('td');
					my $reportFile = "eNB_".$kenb."_RRH_".$krrh."_".$cTime."_report";
					$HTML->tag('a', href=>$reportFile);
			    $HTML->text(${$rrh}{$kenb}{$krrh});
					$HTML->tag('_a');
			    $HTML->tag('_td');
					foreach (@{$items}) {
					  if ( ${$data}{$kenb}{$krrh}{$_} >= $c0Thres ) {
			        $HTML->tag('td', class=>"c0");
						}
						elsif ( ${$data}{$kenb}{$krrh}{$_} >= $c1Thres ) {
			        $HTML->tag('td', class=>"c1");
						}
						elsif ( ${$data}{$kenb}{$krrh}{$_} >= $c2Thres ) {
			        $HTML->tag('td', class=>"c2");
						}
						else {
			        $HTML->tag('td', class=>"c3");
						}
			      $HTML->text(${$data}{$kenb}{$krrh}{$_});
			      $HTML->tag('_td');
					}
			    $HTML->tag('td');
					my $rawTrace = "eNB_".$kenb."_RRH_".$krrh."_".$cTime;
					$HTML->tag('a', href=>$rawTrace);
			    $HTML->text("click here");
					$HTML->tag('_a');
			    $HTML->tag('_td');
			    $HTML->tag('_tr');
					$HTML->nl;
				}
			}

			$HTML->tag('_table');
			$HTML->nl;
			$HTML->tag('_body');
			$HTML->nl;
			$HTML->tag('_html');

	close(FILE);
}

=head1 FUNC update_index

  sub update_index
    update index.html, calculate date within 7 days, get those report file name, then rewrite index.html
  based on template file index.tmpl

=cut

sub update_index {
  my ($current,$dirs,$span) = @_;
	my @history;

	get_hist_list( $current, $span, \@history );
	#print "@history\n";

	my $template = HTML::Template->new(filename=>$dirs.'index.tmpl');
  $template->param(D1=>shift @history);
  $template->param(D2=>shift @history);
  $template->param(D3=>shift @history);
  $template->param(D4=>shift @history);
  $template->param(D5=>shift @history);
  $template->param(D6=>shift @history);
  $template->param(D7=>shift @history);

  my $indexFile = $dirs."index.html";
  open(HFILE, ">$indexFile") or do {
	  RSM::write_log(*HFILE, "KO! Create index.html failure!");
		exit 1;
	};
	print HFILE $template->output;
	close HFILE;
}

open(RFILE, ">>$summaryLog") or die "couldn't open the file\n";
RSM::write_log(*RFILE,"Enter summary.");

## read csv file to get pattern info
if ( RSM::read_csv( $patternConf, $dirs, \@patternRows, 6 ) ) { 
  RSM::write_log(*RFILE,"KO! open pattern.csv error, stop now!"); 
  exit 1; 
}
my $patternItems = find_pattern_number( \@patternRows );

## read csv file to get alarm info
if ( RSM::read_csv( $alarmConf, $dirs, \@alarmRows, 4 ) ) {
  RSM::write_log(*RFILE,"KO! open alarm.csv error, stop now!");
  exit 1;
}
($span) = @{$alarmRows[0]};

my $cTime = RSM::current_time(2);
## DEBUG
#$cTime = "2013_04_09";
save_summary_data( $dirs, $cTime, $searchSuffix, $patternItems, \%summaryData, \@summaryItems );
sort_enb_rrh( \%summaryData, \%enbSort, \%rrhSort );

=comment
foreach (keys %summaryData) {
  print "ENB : $_\n";
	foreach my $rrhp (keys %{$summaryData{$_}}) {
	  print "RRH : $rrhp\n";
		foreach my $items (keys %{$summaryData{$_}{$rrhp}}) {
		  print "$items : $summaryData{$_}{$rrhp}{$items}\n";
		}
	}
	print "\n";
}
foreach my $bb (keys %enbSort ) {
  print "ENB $bb : $enbSort{$bb}\n";
}
foreach my $cc (keys %rrhSort ) {
  foreach my $dd (keys %{$rrhSort{$cc}}) {
	  print "RRH $dd : $rrhSort{$cc}{$dd}\n";
	}
}
=cut

my $myHtmlFile = $dirs.$cTime.".html";
if ( -e $myHtmlFile ) {
  $updateIndexFlag = 0;
}
else {
  $updateIndexFlag = 1;
}
make_html($myHtmlFile,\%summaryData,*RFILE,\@summaryItems,\%enbSort,\%rrhSort,$cTime);

if ( $updateIndexFlag ) {
  update_index($cTime,$dirs,$span);
}

RSM::write_log(*RFILE,"Exit summary.");
close RFILE;

__END__
