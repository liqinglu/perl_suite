#/usr/bin/perl -w

use strict;
use warnings;
use File::Spec;

#######################################################
#  sub split_group                                    #
#    after get all enbs record from enb.csv, we       #
#  group them by group size which get from group.csv, #
#  then call monitor.pl to continue                   #
#                                                     #
#  input para:                                        #
#    $data - the array which include all enb record   #
#    $size - the group size, get from conf file       #
#    $file - file handler                             #
#    $dirs - current app's absolute path              #
#  output para:                                       #
#    no output para                                   #
#  return:                                            #
#    no return                                        #
#######################################################
sub split_group {
  my ($data,$size,$file,$dirs) = @_;
  my $groupTime = 0;
  my $groupCluster = 1;
  my @groupEnb = ();
  my $monitorCmd = $dirs."monitor.pl";

  print "------------------- : start sub split_group!\n";
  foreach ( @{$data} ) {
    push @groupEnb, @{$_};
    $groupTime++;
    if ( !($groupTime % $size) ) {
	    RSM::write_log($file,"Call monitor.pl for enb group $groupCluster.");
      if ( RSM::call_monitor( $monitorCmd, $groupCluster, @groupEnb ) ) {
	      RSM::write_log($file,"KO! in call_monitor, fork process error!");
	    }
	    sleep 1;
	    $groupCluster++;
      $groupTime = 0;
      @groupEnb = ();
    }
  }
  if ( $groupTime != 0 ) {
	  RSM::write_log($file,"Call monitor.pl for enb group $groupCluster.");
    if ( RSM::call_monitor( $monitorCmd, $groupCluster, @groupEnb ) ) {
	    RSM::write_log($file,"KO! in call_monitor, fork process error!");
    }
  }
  print "------------------- : exit sub split_group!\n";
}

#######################################################
##################        main     ####################
#######################################################

## define variables
my $pathCurf = File::Spec->rel2abs(__FILE__);
my ($vol, $dirs, $file) = File::Spec->splitpath($pathCurf);
unshift @INC,$dirs;
require "RSM.pm";
my ( @enbRows, @groupRows, $groupSize );
my $enbConf = "enb.csv";
my $groupConf = "group.csv";
my $mainLog = $dirs.".main.log";

## open the main log file handler
open(FILE,">>$mainLog") or die "couldn't open the main log file!\n";
select FILE;
$| = 1;
RSM::write_log(*FILE,"Enter main!");

## read csv file to get eNB info
if ( RSM::read_csv( $enbConf, $dirs, \@enbRows, 1 ) ) {
  RSM::write_log(*FILE,"KO! open enb.csv error, stop now!");
  exit 1;
}
if ( RSM::read_csv( $groupConf, $dirs, \@groupRows, 2 ) ) {
  RSM::write_log(*FILE,"KO! open group.csv error, stop now!");
  exit 1;
}
$groupSize = $groupRows[0][0];

## group all enbs according to the $groupSize
split_group(\@enbRows, $groupSize, *FILE, $dirs);

RSM::write_log(*FILE,"Exit main!");
close FILE;
select STDIN;

__END__
