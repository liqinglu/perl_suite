#/usr/bin/perl -w

use strict;
use warnings;
use File::Spec;

##############################################
######          main              ############
##############################################
######  read xml file, get enb ip ############
######  and enb id, save those    ############ 
######  info into enb.csv         ############ 
##############################################
######  Argument:                 ############
######  [0]: xml file             ############
##############################################

my $xmlFile = "result.xml";
my $requestFile = "findenb.xml";
my $pathCurf = File::Spec->rel2abs(__FILE__);
my ($vol, $dirs, $file) = File::Spec->splitpath($pathCurf);
unshift @INC,$dirs;
require "RSM.pm";
my @splitName = split(/\./,$xmlFile);
my $readSamLog = $dirs.".readsam.log";

my $samConf = "samconf.csv";
my $groupConf = "group.csv";
my $enbConf = "enb.csv";
my ( @samRows, @enbRows, @groupRows );

open(RFILE, ">>$readSamLog") or die "couldn't open the file\n";
select RFILE;
$| = 1;
RSM::write_log(*RFILE,"Enter readsam.");

if ( RSM::read_csv( $samConf, $dirs, \@samRows, 5 ) ) {
  print "------------------- : read samconf.csv file error!\n";
  exit 1;
}
if ( RSM::read_csv( $groupConf, $dirs, \@groupRows, 2 ) ) {
  print "------------------- : read group.csv file error!\n";
  exit 1;
}

## telnet to sam server, exec SAMO app to generate xml file
RSM::generate_file($xmlFile,$requestFile,\@samRows);
## ftp to sam server, get xml file
RSM::get_file( \@splitName, \@samRows, $xmlFile );

## parse the xml file, get all enb id and enb ip within this sam server
## save all infos into enb.csv
RSM::parse_xml( $dirs, $enbConf, \@samRows, \@splitName, \@groupRows );

print "------------------- : new enb.csv is generated, please check!\n";
RSM::write_log(*RFILE,"Exit readsam.");
close RFILE;
select STDIN;

__END__
