#!/usr/bin/perl -w

use warnings;
use strict;
use File::Spec;

=head1 PROGRAM DESCRIPTION

  clean all kinds of file, based on file generation date and file size, empty the file or compress the file, delete it later

=cut

my $pathCurf = File::Spec->rel2abs(__FILE__);
my ($vol, $dirs, $file) = File::Spec->splitpath($pathCurf);
unshift @INC,$dirs;
require "RSM.pm";

my $cleanFileType = {
                      ".*.log"=>1,        # 1 means empty the file content based on file size
											"eNB*data.csv"=>1,
											"eNB*_report"=>2,      # 2 means compress based on file generation date
											".eNB*_history"=>2,
											"*_*.html"=>2,
											"*.gz"=>3,          # 3 means delete based on file generation date
										};
my $alarmConf = "alarm.csv";
my @alarmRows;

## read csv file to get alarm info
if ( RSM::read_csv( $alarmConf, $dirs, \@alarmRows, 4 ) ) { 
  exit 1; 
}
my ($compress,$txPath,$deleteDay,$fileSize) = @{$alarmRows[0]};

=head1 FUNC file_name_convert

  sub file_name_convert
	  input is a file with suffix "report", so just find out its original trace name and return

=cut

sub file_name_convert {
  my $reportName = shift;
	my (@splitFile,@splitTrace);
	my $traceName;

	@splitFile = split('/',$reportName);
	@splitTrace = split('_',$splitFile[-1]);
	pop @splitTrace;
	$splitFile[-1] = join('_',@splitTrace);
	$traceName = join('/',@splitFile);
}

=head1 FUNC empty

  sub empty
	  loop each file in the list, judge its file size if reach threshold, if yes, empty the file size to 0

=cut

sub empty {
  my $list = shift;
	#DEBUG
  #my $fileSize = 500;

	foreach (@{$list}) {
	  chomp($_);
		#print "$_\n";
		if ( (-s $_) >= $fileSize ) {
		  my @result = qx/> $_/;
		}
	}
}

=head1 FUNC compress_report

  sub compress_report
	  loop each file in the list, if its creation date exceed threshold( get from alarm.csv ), compress 
	it; then find out its original trace file, compress it also.

=cut

sub compress_report {
  my $list = shift;
	my @result;

	foreach (@{$list}) {
	  chomp($_);
		if ( (-M $_) > $compress ) {
		  @result = qx/gzip $_/;
		  my $traceFile = file_name_convert($_);
			@result = qx/gzip $traceFile/;
		}
	}
}

=head1 FUNC compress

  sub compress
	  loop each file in the list, if its creation date exceed threshold( get from alarm.csv ), compress 
	it

=cut

sub compress {
  my $list = shift;

	foreach (@{$list}) {
	  chomp($_);
		if ( (-M $_) > $compress ) {
		  my @result = qx/gzip $_/;
		}
	}
}

=head1 FUNC delete_file

  sub delete_file
	  loop each file in the list, if its creation date exceed threshold( get from alarm.csv ), delete 
	it

=cut

sub delete_file {
  my $list = shift;

	foreach (@{$list}) {
	  chomp($_);
		if ( (-M $_) > $deleteDay ) {
	    #print "$_\n";
		  my @result = qx{/bin/rm -f $_};
		}
	}
}

=head1 FUNC handle

  sub handle
	  a dispatcher, dispatch each task to different function based on different hash value

=cut

sub handle {
  my ($list,$type,$fileType) = @_;

  #print "$type\n";
	#print "@{$list}\n";
  if ( $fileType =~ /report$/ && $type == 2 ) {
	  compress_report($list);
	}
	elsif ( $type == 2 ) {
	  compress($list);
	}
	elsif ( $type == 1 ) {
	  empty($list);
	}
	elsif ( $type == 3 ) {
	  delete_file($list);
	}
}

foreach ( sort { ${$cleanFileType}{$a} <=> ${$cleanFileType}{$b} } keys %{$cleanFileType} ) {
  my @fileList = qx/ls $dirs$_/;
	next if ( scalar @fileList == 0 );
	handle( \@fileList, ${$cleanFileType}{$_}, $_ );
}

__END__
