#!/usr/bin/perl -w

package integrity;

use strict;
use warnings;
use Cwd;
use File::ReadBackwards;
use File::Copy;

sub findcorr {
  my ($somap,$mroitem) = @_;

  foreach (keys %{$somap}) {
    my ($mapindex) = grep {$_ eq $mroitem} @{${$somap}{$_}};
	if ( defined($mapindex) ) {
	  return $_;
	}
  }

  return undef;
}

sub checkmrsdata {
  my ($mref,$mrocsv) = @_;
  my $fh;
  my $flag = 0;
  my @sp;
  my $curmrs;
  my $curobj;
  my %mrocount = ();
  my %mrscount = ();
  my %mroindex = ();

  open($fh, "<$mrocsv") or die "Can't open file $mrocsv: $!";
  while(<$fh>) {
    chomp;
    if ( $flag == 0 ) {
	  @sp = split(',',$_);
	  foreach my $mrefkey (keys %{$mref}) {
	    foreach my $subitem ( @{${$mref}{$mrefkey}} ) {
          my ($mroitemindex) = grep { $sp[$_] eq $subitem } 0..$#sp;
		  $mroindex{$subitem} = $mroitemindex;
		}
	  }
	  $flag = 1;
	}
	else {
      next if ( /^,,,/ );
	  chomp;
	  @sp = split(',',$_);
	  foreach my $mroname ( keys %mroindex ) {
	    if ( $sp[$mroindex{$mroname}] =~ /^\d+$/ ) {
		  if ( defined($mrocount{$sp[0]}{$mroname}) ) {
		    $mrocount{$sp[0]}{$mroname} = $mrocount{$sp[0]}{$mroname} + 1;
		  }
		  else {
		    $mrocount{$sp[0]}{$mroname} = 0;
			$mrocount{$sp[0]}{$mroname} = $mrocount{$sp[0]}{$mroname} + 1;
		  }
		}
	  }
	}
  }
  #foreach my $outter (keys %mrocount) {
  #  foreach my $inner (keys %{$mrocount{$outter}}) {
  #    print "    $outter $inner : $mrocount{$outter}{$inner}\n";
  #	 }
  #}
  close($fh);

  my $mrsflag = 0;
  if ( -e "1.xml" ) {
    open($fh,"<1.xml") or die "Can't open MRS tmp file: $!";
    while(<$fh>) {
      chomp;
	  if ( $mrsflag == 0 ) {
	    foreach my $mkey (keys %{$mref}) {
	      my $matchkey = "measurement mrName=\"".$mkey;
	      if (/$matchkey/) {
	        $curmrs = $mkey;
			$mrsflag = 1;
	      }
	    }
	  }
	  elsif ( $mrsflag == 1 ) {
	    if (/<object id=(.*)>/) {
		  $curobj = $1;
		}
		elsif (/<v>(.*)<\/v>/) {
		  my $sum = 0;
		  map {$sum += $_} split(' ',$1);
		  $mrscount{$curobj}{$curmrs} = $sum;
		}
		elsif (/<\/measurement>/) {
		  $mrsflag = 0;
		}
	  }
    }
    close($fh);

	#foreach my $ott (keys %mrscount) {
	#  foreach my $inn (keys %{$mrscount{$ott}}) {
	#    print "    $ott $inn : $mrscount{$ott}{$inn}\n";
	#  }
	#}
  }
  else {
    die "Can't locate MRS tmp file: $!";
  }

  # output %mrscount and %mrocount, only in %mrocount can be displayed
  foreach my $ott (keys %mrocount) {
    foreach my $inn (keys %{$mrocount{$ott}}) {
	  ##### for 1D MRS
	  my $inncorr = findcorr($mref,$inn);
	  if( defined($inncorr) ) {
	    if ( $mrocount{$ott}{$inn} != $mrscount{$ott}{$inncorr} ) {
		  print "    In MRO $ott $inn $mrocount{$ott}{$inn} vs In MRS $ott $inncorr $mrscount{$ott}{$inncorr}\n";
		}
	  }
	}
  }
}

sub mrocsvexists {
  my ($mrsfile,$mroref) = @_;

  my @spmrs = split(/\./,$mrsfile);
  $spmrs[0] =~ s/MRS/MRO/g;
  ${$mroref} = $spmrs[0].".csv";

  if ( -e ${$mroref} ) {
    return 0;
  }
  else {
    print "    Failed: please check mro file first!\n";
    return 1;
  }
}

sub cleantmpfile {
  my $cmd;

  $cmd = "rm -f 1.xml";
  system($cmd);
}

sub cleantmpuelogfile {
  my $cmd = "rm -f 1.xml";
  system($cmd);
  $cmd = "rm -f 2.xml";
  system($cmd);
}

sub cleanuelogfile {
  my $log = shift;

  my $cmd = "rm -f $log";
  system($cmd);
  $cmd = "rm -f 1.xml";
  system($cmd);
  $cmd = "rm -f 2.xml";
  system($cmd);
}

sub checksuffix {
  my ($file,$csvref) = @_;

  my @sp = split(/\./,$file);
  if( $sp[-1] eq "xml" ) {
    $sp[-1] = "csv";
    ${$csvref} = join("\.",@sp);
    return 1;
  }
  elsif ( $sp[-1] eq "gz" ) {
	pop @sp;
	$sp[-1] = "csv";
	${$csvref} = join("\.",@sp);
    return 2;
  }
  else {
    return 0;
  }
}

sub checkxml {
  my ($mref,$oref,$filename,$m2ref,$o2ref) = @_;

  if ( -e "1.xml" ) {
	open(my $fh,"<1.xml") or die "can't open file : $!";
	open(my $csvh,">$filename") or die "can't open file : $!";
	my $count = 0;
	my $flag = 0;
	my $vflag = 0;
	my $ripflag = 0;
	my $totalrecord = 0;
	my @mindex = ();
	my %oindex = ();
	my @m2index = ();
	my %o2index = ();
	my @sp = ();
	my $objecttitle="id,MmeUeS1apId,MmeGroupId,mmeCode,timeStamp,";
	print $csvh $objecttitle;
	
	while(<$fh>){
	  $count++;
	  if ( /<smr>(.*)<\/smr>/ && $flag == 0 ) {
        print $csvh join(',',split(' ',$1));
		print $csvh "\n";
		$flag = 1;
		@sp = split(' ',$1);
		foreach my $mrefitem ( @{$mref} ) {
		  my ($mrefitemindex) = grep { $sp[$_] eq $mrefitem } 0..$#sp;
  		  push @mindex,$mrefitemindex;
		}
		foreach my $orefkey ( keys %{$oref} ) {
		  my ($orefkeyindex) = grep { $sp[$_] eq $orefkey } 0..$#sp;
		  $oindex{$orefkey} = $orefkeyindex;
		  foreach my $osubitem ( @{${$oref}{$orefkey}} ) {
		    my ($osubindex) = grep { $sp[$_] eq $osubitem } 0..$#sp;
			$oindex{$osubitem} = $osubindex;
		  }
		}

		if ( defined($m2ref) || defined($o2ref) ) {
		  foreach my $mrefitem ( @{$m2ref} ) {
		    my ($mrefitemindex) = grep { $sp[$_] eq $mrefitem } 0..$#sp;
  		    push @m2index,$mrefitemindex;
		  }
		  foreach my $orefkey ( keys %{$o2ref} ) {
		    my ($orefkeyindex) = grep { $sp[$_] eq $orefkey } 0..$#sp;
		    $o2index{$orefkey} = $orefkeyindex;
		    foreach my $osubitem ( @{${$o2ref}{$orefkey}} ) {
		      my ($osubindex) = grep { $sp[$_] eq $osubitem } 0..$#sp;
			  $o2index{$osubitem} = $osubindex;
		    }
		  }
		}
		#print "@m2index\n";
		#foreach (keys %o2index) {
		#  print "$_ : $o2index{$_}\n";
		#}
  	  }
	  elsif ( $ripflag == 0 && $flag == 1 && /<v>(.*)<\/v>/ ) {
	    $totalrecord++;
	    $vflag++;
		print $csvh ",,,,," unless ( $vflag == 1 );
		print $csvh join(',',split(' ',$1));
		print $csvh "\n";

	    my @valuesp = split(' ',$1);
		my @issueindex = ();
		if ( $vflag > 1 && ( defined($m2ref) || defined($o2ref) ) ) { # read other <v> than first <v> in one object
		  foreach my $msingleindex ( @m2index ) {
		    if ( !($valuesp[$msingleindex] =~ /^\d+$/) ) {
	  	      push @issueindex,$msingleindex;
		    }
		  }
		  foreach my $orefsingle ( keys %{$o2ref} ) {
		    if ( $valuesp[$o2index{$orefsingle}] =~ /^\d+$/ ) {
		      foreach ( @{${$o2ref}{$orefsingle}} ) {
		  	    if ( !($valuesp[$o2index{$_}] =~ /^\d+$/) ) {
			      push @issueindex,$o2index{$_};
			    }
			  }
		    }
		  }
		}
		else { # read first <v> in the object
		  foreach my $msingleindex ( @mindex ) {
		    if ( !($valuesp[$msingleindex] =~ /^\d+$/) ) {
	  	      push @issueindex,$msingleindex;
		    }
		  }
		  foreach my $orefsingle ( keys %{$oref} ) {
		    if ( $valuesp[$oindex{$orefsingle}] =~ /^\d+$/ ) {
		      foreach ( @{${$oref}{$orefsingle}} ) {
		  	    if ( !($valuesp[$oindex{$_}] =~ /^\d+$/) ) {
			      push @issueindex,$oindex{$_};
			    }
			  }
		    }
		  }
		}

		if ( @issueindex > 0 ) {
		  print "    Line $count :";
		  foreach my $issueindex ( @issueindex ) {
		    print " $sp[$issueindex] --> $valuesp[$issueindex]";
		  }
		  print " \n";
		}
	  }
	  elsif ( /<object (.*)>/ ) {
	    $vflag = 0;
		$ripflag = 0;
#       if id is like id="90423051:38100:2", so go to next mode /<object (.*)>/
        if ( $1 =~ /id=\"\d+:\d+:\d+\"/ ) {
		  $ripflag = 1;
		  next;
		}
		my @spobject = split(' ',$1);
		foreach ( @spobject ) {
		  my @objectsubitem = split('=',$_);
		  print $csvh $objectsubitem[-1];
		  print $csvh ',';
		}
	  }
	}
	close($fh);
	close($csvh);

	print "    Total Record : $totalrecord\n";
  }
}

sub getMroRules {
  my ($ruleFile,$mref,$oref,$m2ref,$o2ref) = @_;

  open(RF,"<$ruleFile") or die "Can't open file $ruleFile: $!";
  while(<RF>) {
    chomp;
	next if ( /^#/ );
	if ( /^,/ ) {
	  if ( index($_,":") < 0 ) {
	    my $subitem = substr($_,1,length($_));
	    push @{$m2ref},$subitem;
	  }
	  else {
	    next unless s/^,(.*?):\s+//;
	    if ( grep {$_ eq $1} @{$m2ref} ) {
	      my $spref = [split];
	      push @{$m2ref},@{$spref};
	    }
	    else {
	      ${$o2ref}{$1} = [split];
	    }
	  }
	}
	else {
	  if ( index($_,":") < 0 ) {
	    push @{$mref},$_;
	  }
	  else {
	    next unless s/^(.*?):\s+//;
	    if ( grep {$_ eq $1} @{$mref} ) {
	      my $spref = [split];
	      push @{$mref},@{$spref};
	    }
	    else {
	      ${$oref}{$1} = [split];
	    }
	  }
	}
  }
  close(RF);
}

sub getMreRules {
  my ($ruleFile,$mref,$oref) = @_;

  open(RF,"<$ruleFile") or die "Can't open file $ruleFile: $!";
  while(<RF>) {
    chomp;
	next if ( /^#/ );
	if ( index($_,":") < 0 ) {
	  push @{$mref},$_;
	}
	else {
	  next unless s/^(.*?):\s+//;
	  if ( grep {$_ eq $1} @{$mref} ) {
	    my $spref = [split];
	    push @{$mref},@{$spref};
	  }
	  else {
	    ${$oref}{$1} = [split];
	  }
	}
  }
  close(RF);
}

sub getMapping {
  my ($csv,$aref) = @_;

  open(RF,"<$csv") or die "Can't open file $csv: $!";
  while(<RF>) {
    chomp;
	next if ( /^#/ );

    next unless s/^(.*?):\s*//;
	${$aref}{$1} = [split];
  }
  close(RF);
}

sub checkMro {
  my ($dir,$debug) = @_;
  my $csvFile = "mrorules.csv";
  my @mItems = ();
  my %oItems = ();
  my @second_m_items = ();
  my %second_o_items = ();
  my $cmd;
  my $convertcsv;

  print "START TO CHECK MRO:\n";
  getMroRules($csvFile,\@mItems,\%oItems,\@second_m_items,\%second_o_items);
  #print "@second_m_items\n";
  #foreach (keys %second_o_items) {
  #  print "$_ : @{$second_o_items{$_}}\n";
  #}
  my $curPath = cwd;
  opendir(TD,$dir) || die "Can't open $dir: $!";
  chdir $dir;
  my @grepfiles = grep(/^TD.*MRO/,readdir TD);
  my $filenum = @grepfiles;
  print "$filenum MRO FILES TO BE PARSED:\n";
  my @files = sort{ -M "$b" <=> -M "$a" } @grepfiles;
  foreach (@files) {
    my $ret = checksuffix($_,\$convertcsv);
	if ( $ret == 1 ) {
	  $cmd = "/bin/cp -f $_ 1.xml";
	  system($cmd);
	}
	elsif ( $ret == 2 ) {
	  $cmd = "/bin/cp -f $_ 1.xml.gz";
	  system($cmd);
	  $cmd = "gunzip -f 1.xml.gz";
	  system($cmd);
	}
	else {
	  next;
	}

    print "  Analysing $_:\n";
	checkxml(\@mItems,\%oItems,$convertcsv,\@second_m_items,\%second_o_items);
  }
  closedir(TD);
  cleantmpfile();
  chdir $curPath;
  print "STOP CHECK MRO.\n";
}

sub checkMre {
  my ($dir,$debug) = @_;
  my $csvFile = "mrerules.csv";
  my @mItems = ();
  my %oItems = ();
  my $cmd;
  my $convertcsv;

  print "START TO CHECK MRE:\n";
  getMreRules($csvFile,\@mItems,\%oItems);
  #print "@mItems\n";
  #foreach (keys %oItems) {
  #  print "$_ : @{$oItems{$_}}\n";
  #}
  my $curPath = cwd;
  opendir(TD,$dir) || die "Can't open $dir: $!";
  chdir $dir;
  my @grepfiles = grep(/^TD.*MRE/,readdir TD);
  my $filenum = @grepfiles;
  print "$filenum MRE FILES TO BE PARSED:\n";
  my @files = sort{ -M "$b" <=> -M "$a" } @grepfiles;
  foreach (@files) {
    my $ret = checksuffix($_,\$convertcsv);
	if ( $ret == 1 ) {
	  $cmd = "/bin/cp -f $_ 1.xml";
	  system($cmd);
	}
	elsif ( $ret == 2 ) {
	  $cmd = "/bin/cp -f $_ 1.xml.gz";
	  system($cmd);
	  $cmd = "gunzip -f 1.xml.gz";
	  system($cmd);
	}
	else {
	  next;
	}

    print "  Analysing $_:\n";
	checkxml(\@mItems,\%oItems,$convertcsv);
  }
  closedir(TD);
  cleantmpfile();
  chdir $curPath;
  print "STOP CHECK MRE.\n";
}

sub checkMrs {
  my ($dir,$debug) = @_;
  my $csvFile = "mrsmapping.csv";
  my %mItems = ();
  my $cmd;
  my $convertcsv;
  my $mrocsv;

  print "START TO CHECK MRS:\n";
  getMapping($csvFile,\%mItems);
  #foreach ( keys %mItems ) {
  #  print "$_ : @{$mItems{$_}}\n";
  #}
  my $curPath = cwd;
  opendir(TD,$dir) || die "Can't open $dir: $!";
  chdir $dir;
  my @grepfiles = grep(/^TD.*MRS/,readdir TD);
  my $filenum = @grepfiles;
  print "$filenum MRS FILES TO BE PARSED:\n";
  my @files = sort{ -M "$b" <=> -M "$a" } @grepfiles;
  foreach (@files) {
    next if ( mrocsvexists($_,\$mrocsv) );
    my $ret = checksuffix($_,\$convertcsv);
	if ( $ret == 1 ) {
	  $cmd = "/bin/cp -f $_ 1.xml";
	  system($cmd);
	}
	elsif ( $ret == 2 ) {
	  $cmd = "/bin/cp -f $_ 1.xml.gz";
	  system($cmd);
	  $cmd = "gunzip -f 1.xml.gz";
	  system($cmd);
	}
	else {
	  next;
	}

    print "  Analysing $_:\n";
	checkmrsdata(\%mItems,$mrocsv);
  }
  closedir(TD);
  cleantmpfile();
  chdir $curPath;
  print "STOP CHECK MRS.\n";
}

sub checkAll {
  my ($dir,$debug) = @_;

  checkMro($dir,$debug);
  print "\n";
  checkMre($dir,$debug);
  print "\n";
  checkMrs($dir,$debug);
}

sub checksubframe {
  my $fh;
  my @subframe = ();

  if ( -e "1.xml" ) {
    open($fh, "<1.xml") or die "Can't open the file: $!";
	while(<$fh>) {
	  if ( /<object id=\"(\d+:\d+:\d+)\"/ ) {
	    my ($elem) = grep { $_ eq $1 } @subframe; 
		if ( defined($elem) ) {
		  $elem = undef;
		}
		else {
		  push @subframe,$1;
		}
	  }
	}
	foreach (@subframe) {
	  my @sp = split(':',$_);
	  print "    Cell: $sp[0], Earfcn: $sp[1], Subframe: $sp[2]\n";
	}

	close($fh);
  }
}

sub subFrame {
  my ($dir,$debug) = @_;
  my $convertcsv;
  my $cmd;

  print "START TO CHECK SUBFRAME:\n";
  my $curPath = cwd;
  opendir(TD,$dir) || die "Can't open $dir: $!";
  chdir $dir;
  my @grepfiles = grep(/^TD.*MRO/,readdir TD);
  my $filenum = @grepfiles;
  print "$filenum FILES TO BE PARSED:\n";
  my @files = sort{ -M "$b" <=> -M "$a" } @grepfiles;
  foreach (@files) {
    my $ret = checksuffix($_,\$convertcsv);
	if ( $ret == 1 ) {
	  $cmd = "/bin/cp -f $_ 1.xml";
	  system($cmd);
	}
	elsif ( $ret == 2 ) {
	  $cmd = "/bin/cp -f $_ 1.xml.gz";
	  system($cmd);
	  $cmd = "gunzip -f 1.xml.gz";
	  system($cmd);
	}
	else {
	  next;
	}
    print "  Analysing $_:\n";

	checksubframe();
  }
  closedir(TD);
  cleantmpfile();
  chdir $curPath;
  print "STOP CHECK SUBFRAME.\n";
}

sub cellalready {
  my ($str,$obj,$rf) = @_;

  my ($index) = grep {$_ eq $str} @{${$rf}{$obj}};
  if( defined($index) ) {
    return 1;
  }
  else {
    return 0;
  }
}

sub checkcellinfo {
  my $fh;
  my @cellitems = ("MR.LteScEarfcn","MR.LteScPci","MR.LteNcEarfcn","MR.LteNcPci","MR.GsmNcellBcch","MR.GsmNcellNcc","MR.GsmNcellBcc","MR.TdsNcellUarfcn","MR.TdsCellParameterId");
  my %cellitemindex = ();
  my $obj;
  my %basicinfo = ();
  my %ncinfo = ();
  my %tdsinfo = ();
  my %gsminfo = ();
  my $ripflag = 0;
  my $eventtype;
 
  if ( -e "1.xml" ) {
    open($fh,"<1.xml") or die "Can't open file: $!";
	while(<$fh>) {
	  if ( /<smr>(.*)<\/smr>/ ) {
	    my @spitem = split(' ',$1);
		foreach my $item (@cellitems) {
		  my ($cellitem) = grep {$spitem[$_] eq $item} 0..$#spitem;
		  $cellitemindex{$item} = $cellitem if ( defined($cellitem) );
		  $cellitem = undef;
		}
	  }
	  elsif ( /<object id=\"(\S+)\"/ ) {
	    if ( $1 =~ /\d+:\d+:\d+/ ) {
		  $ripflag = 1;
		}
		else {
		  $ripflag = 0;
		  $obj = $1;
		  if ( /EventType=\"(\S+)\"/ ) {
		    $eventtype = $1;
		  }
		}
	  }
	  elsif ( /<v>(.*)<\/v>/ && $ripflag == 0 ) {
	    my @cellvalue = split(' ',$1);
		if ( $cellvalue[$cellitemindex{"MR.LteScEarfcn"}] =~ /^\d+$/ && $cellvalue[$cellitemindex{"MR.LteScPci"}] =~ /^\d+$/ ) {
		  $basicinfo{$obj} = $cellvalue[$cellitemindex{"MR.LteScEarfcn"}].":".$cellvalue[$cellitemindex{"MR.LteScPci"}];
		}

        # only MRE file contain "EVENTTYPE"
		if ( defined($eventtype) ) {
		  if ( $eventtype =~ /A[12]/ ) {
		  }
		  elsif ( $eventtype =~ /A[3456]/ ) {
            # neighbour cell
		    if ( $cellvalue[$cellitemindex{"MR.LteNcEarfcn"}] =~ /^\d+$/ || $cellvalue[$cellitemindex{"MR.LteNcPci"}] =~ /^\d+$/ ) {
		      if ( !cellalready( $cellvalue[$cellitemindex{"MR.LteNcEarfcn"}].":".$cellvalue[$cellitemindex{"MR.LteNcPci"}], $obj, \%ncinfo ) ) {
		        push @{$ncinfo{$obj}},$cellvalue[$cellitemindex{"MR.LteNcEarfcn"}].":".$cellvalue[$cellitemindex{"MR.LteNcPci"}];
		      }
		    }
		  }
		  elsif ( $eventtype =~ /B[12]/ ) {
            # GSM cell
		    if ( $cellvalue[$cellitemindex{"MR.GsmNcellBcc"}] =~ /^\d+$/ || $cellvalue[$cellitemindex{"MR.GsmNcellNcc"}] =~ /^\d+$/ || $cellvalue[$cellitemindex{"MR.GsmNcellBcch"}] =~ /^\d+$/ ) {
		      if ( !cellalready( $cellvalue[$cellitemindex{"MR.GsmNcellBcc"}].":".$cellvalue[$cellitemindex{"MR.GsmNcellNcc"}].":".$cellvalue[$cellitemindex{"MR.GsmNcellBcch"}], $obj, \%gsminfo ) ) {
		        push @{$gsminfo{$obj}},$cellvalue[$cellitemindex{"MR.GsmNcellBcc"}].":".$cellvalue[$cellitemindex{"MR.GsmNcellNcc"}].":".$cellvalue[$cellitemindex{"MR.GsmNcellBcch"}];
		      }
		    }
  
            # TDs cell
  		    if ( $cellvalue[$cellitemindex{"MR.TdsNcellUarfcn"}] =~ /^\d+$/ || $cellvalue[$cellitemindex{"MR.TdsCellParameterId"}] =~ /^\d+$/ ) {
		      if ( !cellalready( $cellvalue[$cellitemindex{"MR.TdsNcellUarfcn"}].":".$cellvalue[$cellitemindex{"MR.TdsCellParameterId"}], $obj, \%tdsinfo ) ) {
		        push @{$tdsinfo{$obj}},$cellvalue[$cellitemindex{"MR.TdsNcellUarfcn"}].":".$cellvalue[$cellitemindex{"MR.TdsCellParameterId"}];
		      }
		    }
		  }
		  else {
		  }
		}
		# It is MRO file
		else {
          # neighbour cell
		  if ( $cellvalue[$cellitemindex{"MR.LteNcEarfcn"}] =~ /^\d+$/ || $cellvalue[$cellitemindex{"MR.LteNcPci"}] =~ /^\d+$/ ) {
		    if ( !cellalready( $cellvalue[$cellitemindex{"MR.LteNcEarfcn"}].":".$cellvalue[$cellitemindex{"MR.LteNcPci"}], $obj, \%ncinfo ) ) {
		      push @{$ncinfo{$obj}},$cellvalue[$cellitemindex{"MR.LteNcEarfcn"}].":".$cellvalue[$cellitemindex{"MR.LteNcPci"}];
		    }
		  }

          # GSM cell
		  if ( $cellvalue[$cellitemindex{"MR.GsmNcellBcc"}] =~ /^\d+$/ || $cellvalue[$cellitemindex{"MR.GsmNcellNcc"}] =~ /^\d+$/ || $cellvalue[$cellitemindex{"MR.GsmNcellBcch"}] =~ /^\d+$/ ) {
		    if ( !cellalready( $cellvalue[$cellitemindex{"MR.GsmNcellBcc"}].":".$cellvalue[$cellitemindex{"MR.GsmNcellNcc"}].":".$cellvalue[$cellitemindex{"MR.GsmNcellBcch"}], $obj, \%gsminfo ) ) {
		      push @{$gsminfo{$obj}},$cellvalue[$cellitemindex{"MR.GsmNcellBcc"}].":".$cellvalue[$cellitemindex{"MR.GsmNcellNcc"}].":".$cellvalue[$cellitemindex{"MR.GsmNcellBcch"}];
		    }
		  }
  
          # TDs cell
  		  if ( $cellvalue[$cellitemindex{"MR.TdsNcellUarfcn"}] =~ /^\d+$/ || $cellvalue[$cellitemindex{"MR.TdsCellParameterId"}] =~ /^\d+$/ ) {
		    if ( !cellalready( $cellvalue[$cellitemindex{"MR.TdsNcellUarfcn"}].":".$cellvalue[$cellitemindex{"MR.TdsCellParameterId"}], $obj, \%tdsinfo ) ) {
		      push @{$tdsinfo{$obj}},$cellvalue[$cellitemindex{"MR.TdsNcellUarfcn"}].":".$cellvalue[$cellitemindex{"MR.TdsCellParameterId"}];
		    }
		  }
		}

		$eventtype = undef;
	  }
	}
	close($fh);

    foreach (keys %basicinfo) {
	  print "    Serving Cell $_ -- $basicinfo{$_}\n";
	  if ( exists($ncinfo{$_}) ) {
	    print "      neighbour cell:\n";
		foreach my $ncelem ( @{$ncinfo{$_}} ) {
		  my @spncelem = split(':',$ncelem);
		  print "        LteNcEarfcn : $spncelem[0] , LteNcPci : $spncelem[1]\n";
		}
	  }
	  if ( exists($gsminfo{$_}) ) {
	    print "      gsm cell:\n";
		foreach my $gsmelem ( @{$gsminfo{$_}} ) {
		  my @spgsmelem = split(':',$gsmelem);
		  print "        GsmNcellBcc : $spgsmelem[0] , GsmNcellNcc : $spgsmelem[1] , GsmNcellBcch : $spgsmelem[2]\n";
		}
	  }
	  if ( exists($tdsinfo{$_}) ) {
	    print "      TDs cell:\n";
		foreach my $tdselem ( @{$tdsinfo{$_}} ) {
		  my @sptdselem = split(':',$tdselem);
		  print "        TdsNcellUarfcn : $sptdselem[0] , TdsCellParameterId : $sptdselem[1]\n";
		}
	  }
	}
  }
}

sub cellInfo {
  my ($dir,$debug) = @_;
  my $convertcsv;
  my $cmd;

  print "START TO CHECK CELLINFO:\n";
  my $curPath = cwd;
  opendir(TD,$dir) || die "Can't open $dir: $!";
  chdir $dir;
  my @grepfiles = grep(/^TD.*MR[OE]/,readdir TD);
  my $filenum = @grepfiles;
  print "$filenum FILES TO BE PARSED:\n";
  my @files = sort{ -M "$b" <=> -M "$a" } @grepfiles;
  foreach (@files) {
    my $ret = checksuffix($_,\$convertcsv);
	if ( $ret == 1 ) {
	  $cmd = "/bin/cp -f $_ 1.xml";
	  system($cmd);
	}
	elsif ( $ret == 2 ) {
	  $cmd = "/bin/cp -f $_ 1.xml.gz";
	  system($cmd);
	  $cmd = "gunzip -f 1.xml.gz";
	  system($cmd);
	}
	else {
	  next;
	}
    print "  Analysing $_:\n";

	checkcellinfo();
  }
  closedir(TD);
  cleantmpfile();
  chdir $curPath;
  print "STOP CHECK CELLINFO.\n";
}

sub chfm {
  my ($tim) = @_;

  my @sp = split('\.',$tim);

  return $sp[0];
}

sub finduets {
  my ($logfile,$begin,$end) = @_;
  my $fh;
  my $line;

  open($fh,"<$logfile") or die "Can't open ue log file: $!";
  while(<$fh>) {
    if (/Computer Timestamp: (.*)/) {
	  #print "$1\n";
	  ${$begin} = chfm($1);
	  last;
	}
  }
  close($fh);

  my $bw = File::ReadBackwards->new($logfile) or die "Can't open ue log file: $!";
  while( defined($line = $bw->readline) ) {
    if ( $line =~ /Computer Timestamp: (.*)/ ) {
	  #print "$1\n";
	  ${$end} = chfm($1);
	  last;
	}
  }
  $bw->close;
}

sub hourtransfer {
  my $ho = shift;

  if( $ho >=00 && $ho<15 ) {
    return "00";
  }
  elsif( $ho >=15 && $ho<30 ) {
    return "15";
  }
  elsif( $ho >=30 && $ho<45 ) {
    return "30";
  }
  else {
    return "45";
  }
}

sub findmrts {
  my ($begin,$end,$mrbegin,$mrend) = @_;
  my @spt;
  my $mrh;

  #print "$begin\n";
  #print "$end\n";
  # suppose collect granularity is 15 min
  @spt = split(':',$begin);
  $mrh = hourtransfer($spt[1]);
  ${$mrbegin} = $spt[0].$mrh."00";

  @spt = ();
  @spt = split(':',$end);
  $mrh = hourtransfer($spt[1]);
  ${$mrend} = $spt[0].$mrh."00";
}

sub openmr {
  my ($mro,$mre,$fdir,$tm) = @_;
  my $suf;

  my $checkts = "MR[OE]".".*".$tm;
  my @grepfiles = grep(/$checkts/, readdir $fdir);
  if ( @grepfiles == 0 ) {
    die "No mapping MR files: $!";
  }
  else {
    foreach (@grepfiles) {
	  if (/MRO/) {
        my $ret = checksuffix($_,\$suf);
        if ( $ret == 1 ) {
	      my $cmd = "cp -f $_ 1.xml";
	      system($cmd);
          open(${$mro},"<1.xml") or die "Can't open MRO file: $!";
	    }
	    elsif ( $ret == 2 ) {
	      my $cmd = "cp -f $_ 1.xml.gz";
	      system($cmd);
	      $cmd = "gunzip 1.xml.gz";
	      system($cmd);
	      open(${$mro},"<1.xml") or die "Can't open MRO file: $!";
	    }
	    else {
	      die "MRO file format wrong: $!";
	    }
	  }
	  elsif ( /MRE/ ) {
        my $ret = checksuffix($_,\$suf);
        if ( $ret == 1 ) {
	      my $cmd = "cp -f $_ 2.xml";
	      system($cmd);
          open(${$mre},"<2.xml") or die "Can't open MRE file: $!";
	    }
	    elsif ( $ret == 2 ) {
	      my $cmd = "cp -f $_ 2.xml.gz";
	      system($cmd);
	      $cmd = "gunzip 2.xml.gz";
	      system($cmd);
	      open(${$mre},"<2.xml") or die "Can't open MRE file: $!";
	    }
	    else {
	      die "MRE file format wrong: $!";
	    }
	  }
	}
  }
}

sub add15min {
  my $tm = shift;
  my $ret;

  my $min = substr($tm,2,2);
  my $ho = substr($tm,0,2);
  my $sec = substr($tm,4,2);

  $min = $min + 15;
  if ( $min == 60 ) {
    $min = "00";
	$ho = $ho + 1;
	$ho = sprintf("%02d",$ho);
	$ret = $ho.$min.$sec;
  }
  else {
    $ret = $ho.$min.$sec;
  }

  return $ret;
}

sub getminsec {
  my ($sptime,$minref,$secref,$usec) = @_;

  my @spt = split(':',$sptime);
  ${$minref} = $spt[1];
  my @spsec = split(/\./,$spt[-1]);
  ${$secref} = $spsec[0];
  ${$usec} = $spsec[1];
}

sub calculatesecgap {
  my ($mrtim,$uetim) = @_; # input format 17:29:25.941
  my ($mrmin,$mrsec,$uemin,$uesec,$mrusec,$ueusec);

  getminsec($mrtim,\$mrmin,\$mrsec,\$mrusec);
  getminsec($uetim,\$uemin,\$uesec,\$ueusec);

  return ($mrmin*60*1000+$mrsec*1000+$mrusec)-($uemin*60*1000+$uesec*1000+$ueusec);
}

sub spmrtime {
  my ($tim,$min,$sec,$usec) = @_;

  my @sp1 = split('T',$tim);
  my @sp2 = split(':',$sp1[1]);
  my @sp3 = split(/\./,$sp2[2]);

  ${$min} = $sp2[1];
  ${$sec} = $sp3[0];
  ${$usec} = $sp3[1];
}

sub whoisearlier {
  my ($mrotime,$mretime) = @_; # input format 2013-12-19T17:29:25.941

  my ($mromin,$mrosec,$mrousec);
  my ($mremin,$mresec,$mreusec);

  spmrtime($mrotime,\$mromin,\$mrosec,\$mrousec);
  spmrtime($mretime,\$mremin,\$mresec,\$mreusec);

  if ( ($mromin*60*1000+$mrosec*1000+$mrousec)-($mremin*60*1000+$mresec*1000+$mreusec) > 0 ){
    return 2;
  }
  else {
    return 1;
  }
}

sub combinemr {
  my ($mro,$mre,$data) = @_;
  my ($linemro,$linemre);
  my ($mrotime,$mretime);

  @{$data} = ();
  while($linemro=<$mro>) {
    if ( $linemro =~ /<object.*timeStamp=\"(.*)\+08:00\">/ ) {
	  $mrotime = $1;
	  last;
	}
	$linemro = undef;
  }
  while($linemre=<$mre>) {
    if ( $linemre =~ /<object.*timeStamp=\"(.*)\+08:00\">/ ) {
	  $mretime = $1;
	  last;
	}
	$linemre = undef;
  }

  if ( !defined($linemro) && !defined($linemre) ) { # no data
    @{$data} = ();
	return;
  }
  elsif ( !defined($linemro) && defined($linemre) ) { # only mre data
    push @{$data},$linemre;
	while(<$mre>){
	  if (/<\/measurement>/) {
	    return;
	  }
	  else{
	    push @{$data},$_;
	  }
	}
  }
  elsif ( defined($linemro) && !defined($linemre) ) { # only mro data
    push @{$data},$linemro;
	while(<$mro>){
	  if (/<\/measurement>/) {
	    return;
	  }
	  else{
	    push @{$data},$_;
	  }
	}
  }
  else { # both have data
    while(1) {
      my $ret = whoisearlier($mrotime,$mretime);
	  if ( $ret == 1 ) { # mrotime is early than mretime, including mrotime is equal to mretime
	    push @{$data},$linemro;
		while(<$mro>){
		  if (/<object.*timeStamp=\"(.*)\+08:00\">/) {
		    $mrotime = $1;
			next;
		  }
		  elsif (/<\/measurement>/) { # EOF of MRO, write all MRE data
		    push @{$data},$linemre;
			while(<$mre>){
			  if (/<\/measurement>/) {
			    last;
			  }
			  else {
			    push @{$data},$_;
			  }
			}
		    last;
		  }
		  else {
		    push @{$data},$_;
		  }
		}
	  }
	  else { # mretime is early than mrotime
	    push @{$data},$linemre;
		while(<$mre>){
		  if (/<object.*timeStamp=\"(.*)\+08:00\">/) {
		    $mretime = $1;
			next;
		  }
		  elsif (/<\/measurement>/) { # EOF of MRE, write all MRO data
		    push @{$data},$linemro;
			while(<$mro>){
			  if (/<\/measurement>/) {
			    last;
			  }
			  else {
			    push @{$data},$_;
			  }
			}
		    last;
		  }
		  else {
		    push @{$data},$_;
		  }
		}
	  }
	}
  }
}

sub findmrmapping {
  my ($tslot,$rsrp,$rsrq,$fmro,$fmre,$dirh,$begintime,$secgap,$endtime,$mgroup,$data) = @_;
  my $rsrpidx = 0;
  my $rsrqidx = 2;
  my $nextflag = 0;
  my $mrtime;
  my $abloopflag = 0;

  foreach my $line (@{$data}) {
	if ( defined($line) && $line =~ /<object.*MmeUeS1apId=\"(.*)\" MmeGroupId.*timeStamp=\"(.*)\+08:00\">/ ) {
	  my ($mmeexist) = grep {$_ eq $1} @{$mgroup};
	  if ( !defined($mmeexist) ) {
		next;
	  }
	  $mmeexist = undef;
	  $mrtime = $2;
	  my @spt = split('T',$2);
	  my $sgap = calculatesecgap($spt[1],${$tslot});
	  if ( $sgap <= $secgap*1000 && $sgap >= 0 ) {  # valid object
	    $nextflag = 1;
 	  }
	  elsif ( $sgap > $secgap*1000 ) {  # invalid, may stop searching ~~~
	    print "  KO : MR $2 ~~ UE ${$tslot}\n";
		print "    --Can't find MR record around UE report time\n";
		exit 1;
	  }
	  else { # find next object
	    $line = undef;
		next;
	  }
	}
	elsif ($nextflag == 1) {
	  if ( defined($line) && $line =~ /<v>(.*)<\/v>/ ) {
		  my @value = split(' ',$1);
		  if ( $value[$rsrpidx] == ${$rsrp} && $value[$rsrqidx] == ${$rsrq} ) {
		    print "  OK : MR $mrtime ~~ UE ${$tslot}\n";
			$abloopflag = 1;
			last;
		  }
		  else {
		    print "  KO : MR $mrtime ~~ UE ${$tslot}\n";
			print "    --RSRP/RSRQ is inconsistent comparing to the UE report\n";
			exit 1;
		  }
	  }
	}
  }

  # if here, it indicate no mr record found in this time period, we should find next time peirod MR files if it has
  return $abloopflag;
}

sub ueLog {
  my ($dir,$uelog,$debug) = @_;
  my $cmd;
  my $bt;
  my $et;
  my $mrbt;
  my $mret;
  my $checkts;
  my $fh;
  my ($cts,$crsrq,$crsrp);
  my ($sec,$mmeapid);
  my @mmegroup;
  my ($fmro,$fmre);

  print "How many seconds delay on MR comparing to UE log?(s)\n";
  $sec=<STDIN>;;
  chomp($sec);
  $sec = 4 unless ( defined($sec) );

  print "Please input MmeUeS1apId candidate value?(Example: 255901151 255901152)\n";
  $mmeapid=<STDIN>;;
  chomp($mmeapid);
  @mmegroup = split(' ',$mmeapid);
  #@mmegroup = (255901151);

  print "START TO CHECK UELOG:\n";
  my $curPath = cwd;
  chdir $dir;
  cleanuelogfile($uelog);
  chdir $curPath;
  finduets($uelog,\$bt,\$et); # find first and last time stamp of MR message from UE log
  findmrts($bt,$et,\$mrbt,\$mret);
  copy($uelog,$dir);
  chdir $dir;

  my $dh;
  opendir($dh,$dir) || die "Can't open $dir: $!";
  openmr(\$fmro,\$fmre,$dh,$mrbt);
  my @mrdata;
  combinemr($fmro,$fmre,\@mrdata);
  die " No MR data: $!" if (@mrdata==0);
  #print "@mrdata\n";

  open($fh,"<$uelog") or die "Can't open ue log file in $dir: $!";
  my $rsrqid = 0;
  my $ueline;
  while(<$fh>) {
    if ( /^MeasurementReport/ ) {
	  for(my $i=0;$i<3;$i++) {
	    $ueline = <$fh>;
	  }
	  if ( $ueline =~ /Computer Timestamp: (.*)/ ) {
	    $cts = $1;
		$rsrqid = 1;
	  }
	}
	elsif ( /measResultServCell/ && $rsrqid == 1 ) {
	  $rsrqid = 2;
	}
	elsif ( /rsrpResult: (.*)/ && $rsrqid == 2 ) {
	  $crsrp = $1;
	  $rsrqid = 3;
	}
	elsif ( /rsrqResult: (.*)/ && $rsrqid == 3 ) {
	  $crsrq = $1;
	  $rsrqid = 0;
	  for (;;) {
	    my $ret = findmrmapping(\$cts,\$crsrp,\$crsrq,$fmro,$fmre,$dh,$mrbt,$sec,$mret,\@mmegroup,\@mrdata);
	    if ( !$ret ) {  # need to handle next MR files
		  if ( $mrbt eq $mret ) {
			print "  No more MR files to be checked, exit abnormally\n";
			exit 1;
		  }
		  else {
		    $mrbt = add15min($mrbt);
		    close($fmro);
		    close($fmre);
			closedir($dh);
			cleantmpuelogfile();
            opendir($dh,$dir) || die "Can't open $dir: $!";
            openmr(\$fmro,\$fmre,$dh,$mrbt);
            combinemr($fmro,$fmre,\@mrdata);
            die "  No MR data: $!" if (@mrdata==0);
		  }
	    }
		else {
		  last;
		}
	  }
	  $cts = undef;
	  $crsrp = undef;
	  $crsrq = undef;
	}
  }
  close($fmro) if ( defined($fmro) );
  close($fmre) if ( defined($fmre) );
  close($fh);
  closedir($dh);
  cleanuelogfile($uelog);
  chdir $curPath;
  print "STOP CHECK UELOG.\n";
}

1;
