#!/usr/bin/perl -w

use strict;
use warnings;
use Getopt::Long;
use integrity;

my ( $help, $debug, $option );

GetOptions(
  'help|h!' => \$help,
  'debug|d:i' => \$debug,
  'option|o:s' => \$option,
);

if ( defined($help) ) {
  print "Usage: perl integritycheck.pl [--help|-h] [--debug|-d <level>] [--option|-o <option>] MRdirectory [uelog file]\n";
  print "       --help|-h\n"; 
  print "       --option|-o candidate value:\n";
  print "            all\n";
  print "      	    mrocheck\n";
  print "      	    mrecheck\n";
  print "      	    mrscheck\n";
  print "      	    subframe\n";
  print "      	    cellinfo\n";
  print "      	    uelog\n";
  print "       --debug|-d [0|1|2...]\n";
  exit(0);
}

die "Not define directory, please find help option for usage\n" unless ( $#ARGV >= 0 );
$debug = 0 unless defined($debug);

if ( defined($option) ) {
  if ( lc($option) eq "all" ) {
    integrity::checkAll($ARGV[0],$debug);
	exit 0;
  }
  elsif ( lc($option) eq "mrocheck" ) {
    integrity::checkMro($ARGV[0],$debug);
	exit 0;
  }
  elsif ( lc($option) eq "mrecheck" ) {
    integrity::checkMre($ARGV[0],$debug);
	exit 0;
  }
  elsif ( lc($option) eq "mrscheck" ) {
    integrity::checkMrs($ARGV[0],$debug);
	exit 0;
  }
  elsif ( lc($option) eq "subframe" ) {
    integrity::subFrame($ARGV[0],$debug);
	exit 0;
  }
  elsif ( lc($option) eq "cellinfo" ) {
    integrity::cellInfo($ARGV[0],$debug);
	exit 0;
  }
  elsif ( lc($option) eq "uelog" ) {
    die "Not define ue log file, please find help option for usage\n" unless ( $#ARGV == 1 );
    integrity::ueLog($ARGV[0],$ARGV[1],$debug);
	exit 0;
  }
  else {
    die "Wrong content for parameter => option, please assign again\n";
  }
}
else {
  die "Not defined parameter => option, please find help option for usage\n";
}

__END__

=head1 NAME

integritycheck.pl

=head1 SYNOPSIS

perl integritycheck.pl --help|-h

perl integritycheck.pl --option|-o [action] <MR dir>

  --option|-o [action] : so far for [action], allowed value are "all","mrocheck","mrecheck","mrscheck","subframe","cellinfo".
  MR dir               : MR directory to be checked.

perl integritycheck.pl --option|-o uelog <MR dir> <ue log> 
  note: this is format for uelog checking 
  
=head1 DESCRIPTION

This program is used to verify if MR data is valid.

MROCHECK

If option is "mrocheck", it will analyse mro rule file named "mrorules", it defines which dimension to be checked and dimension dependances between. A quick example for rule file "mrorules":

MR.LteScRSRP

MR.LteScSinrUL

MR.LteScPHR

MR.LteScRSRP: MR.LteScEarfcn MR.LteScPci

MR.LteNcRSRP: MR.LteNcEarfcn MR.LteNcPci

From the rule file, we can see some mandatory dimension and dimension dependancy whatever it's mandatory or optional, MR.LteScRSRP/MR.LteScSinrUL/MR.LteScPHR are mandatory dimension, their values should be checked in MRO file; The fourth line : MR.LteScEarfcn and MR.LteScPci depend on mandatory dimension MR.LteScRSRP, so they are also mandatory dimension; MR.LteNcEarfcn and MR.LteNcPci depend on MR.LteNcRSRP which is optional dimension, so it means if MR.LteNcRSRP exists, MR.LteNcEarfcn and MR.LteNcPci must exist. Also, the tool will generate csv file from MRO file by default, so it's easy for user to check the MRO data by third party tool.

How to generate the rule file, some points should be followed:

1. Single mandatory dimension should be first

2. Single mandatory dimension can't write twice except in dependance expression 

3. Whatever first or last for mandatory dependancy relation and optional dependancy relation

MRECHECK

If option is "mrecheck", it is similar with "mrocheck", its rule file name is "mrerules", so everything you can reference "mrocheck". Also, the tool will generate csv file from MRE file by default, so it's easy for user to check the MRE data by third party tool.

MRSCHECK

If option is "mrscheck", it only maintain a mapping file "mrsmapping", which defines the one dimension but two names in MRO and MRS seperately. A quick instance for "mrsmapping" file:

MR.RSRP:MR.LteScRSRP

so the first one is dimension in MRS, the second one is dimension in MRO, the program will sum all the count for the same dimension in MRO and MRS seperately, if two value is inconsistent, it will warn.

ALL

If option is "all", it will execute "mrocheck","mrecheck","mrscheck" by sequence, so in most time, it is a more easy way.

SUBFRAME

If option is "subframe", it only check MRO file, picking up object like "object id="84047107:38050:2"", and report it with below format: Cell,Earfcn,Subframe

CELLINFO

If option is "cellinfo", it will check MRO&MRE files, for each serving cell, it collect all neighbour cell info , gsm cell info , td-scdma info and basic info like LteScEarfcn and LteScPci

UELOG

If option is "uelog", it will map UE measurement record with MRO&MRE files in the same time frame. It provides two inputs, one is MR files directory, the other is UE log. Some restriction for this option is : 

1. UE log need to be customized, the first record should be the first valid measurement report, the last record should be the last valid measurement report; 

2. UE log can't span multi days, all UE log should be collected in one day

when execute uelog option, user need to input 2 parameter: 

1. time gap between MRx files and UE log; if time of TCE and UE are synchronised, so this value should be 0,but in most of time, there may be a gap between the two elements. 

2. MMEapID; it's used to identified a UE, the value should be a single or a set, seperate by " ".

=head1 AUTHORS

Li Qinglu

=head1 COPYRIGHT

Copyright (c) 2014-  All rights reserved.This program is free software; you may redistribute it and/ormodify it under the same terms as Perl itself.

=cut
