#!/usr/bin/perl -w

use strict;
use warnings;
use Cwd;

sub getfromtime {
  my $input = shift;

  my ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)=localtime($input);
  $year += 1900;
  $mon += 1;
  $mon = sprintf("%02d",$mon);
  $mday = sprintf("%02d",$mday);
  $hour = sprintf("%02d",$hour);
  $min = sprintf("%02d",$min);
  $sec = sprintf("%02d",$sec);

  my $newtime = $year."-".$mon."-".$mday." ".$hour.":".$min.":".$sec;
  return $newtime;
}

sub bin2int {
  my ($input) = @_;

  my $sum = 0;
  my $count = 0;
  my @spbin = split(//,$input);

  while(1) {
    if( defined(my $binvalue = pop @spbin) ) {
	  $sum += $binvalue * ( 2 ** $count );
	  $count++;
	}
	else {
	  return $sum;
	}
  }
}

sub gettypes {
  my $href = shift;

  my $fh;
  open($fh,"type.csv") or die "Can't open file : $!";
  while(<$fh>){
    my ($type,$value) = /(\d+),(\d+)/;
	#print "$type : $value\n";
	${$href}{$type} = $value;
  }
  close($fh);
}

sub inithash {
  my ($interface,$enb,$type) = @_;

  foreach ( @{$type} ) {
    ${$interface}{$_} = 0;
  }
}

sub deletelastres {
  my $cmd;

  $cmd = "/bin/rm -f *.csv";
  system($cmd);
  $cmd = "/bin/rm -f *.txt";
  system($cmd);
}

# START
die "Please input data directory" unless ( $#ARGV == 0 ) ;

# open wrong record file handler
my $wrongfh;
open($wrongfh,">>sca.log") or die "Can't open file : $!";

# init
my $count          = 0;
my $uuextmax       = 0;
my $uuextmin       = 10000000000000000;
my $uuextsum       = 0;
my $uuextcount     = 0;
my $newlineflag    = 0;
my ($totalstr,$data,$tmplen);
my ($fh,$wfh,$uufh,$uuextfh,$x2fh);
my ($uuextavg,$uuextlasttime);
my @interf         = qw(UU UU-EXT X2);
my %interfacecount = ();
my %enbcount       = ();
my @uuextavg       = ();
my %types          = ();
inithash(\%interfacecount,\%enbcount,\@interf);
gettypes(\%types);

# start to read SCA data directory
opendir(TD,$ARGV[0]) or die "Can't open dir : $!";
chdir $ARGV[0];
deletelastres();
my (@files,@grepfiles);
@grepfiles = grep("*.data",readdir TD);
@files = sort { -C "$b" <=> -C "$a" } @grepfiles;
foreach ( @files ) {
  next if /^\./;
  #print "$_\n";
  my $newfile = $_;
  $newfile =~ s/data/txt/g;
  open($fh,$_) or die "Can't open file $_ : $!";
  open($wfh,">$newfile") or die "Can't open file $newfile : $!";
  binmode($fh);
  binmode($wfh);
  my $x2file = $_;
  $x2file =~ s/data/x2\.csv/g;
  open($x2fh,">$x2file") or die "Can't open file $x2file : $!";
  print $x2fh "ver,cardtype,time,time2,netelement,interface,dir,sourceenbid,destenbid,cellid","\n";
  my $uufile = $_;
  $uufile =~ s/data/uu\.csv/g;
  open($uufh,">$uufile") or die "Can't open file $uufile : $!";
  print $uufh "ver,cardtype,time,time2,netelement,interface,dir,channeltype,enbid,cellid,crnti,mmeues1apid,mmegroupid,mmecode","\n";
  my $uuextfile = $_;
  $uuextfile =~ s/data/uuext\.csv/g;
  open($uuextfh,">$uuextfile") or die "Can't open file $uuextfile : $!";
  print $uuextfh "ver,cardtype,time,time2,netelement,interface,dir,sampletype,enbid,cellid,crnti,mmeues1apid,mmegroupid,mmecode","\n";
  $uuextlasttime = 0;

  while( read( $fh,$data,2 ) ) {
    my ($totallen) = unpack('H*',$data);
	read( $fh,$totalstr,hex $totallen );
	$count++;

	print $wfh "################### message $count ##################################\n";
    #print length($_)," -- ",unpack('H*',$totalstr),"\n";
    my ($ver,$cardtype,$time,$time2,$netelement,$interface,$dir,$left) = unpack('H2H2H8H8H2H2H2H*',$totalstr);
    print $wfh "Totallen : ",hex $totallen,"\n";
    print $wfh "\nGeneral package --\n";
    print $wfh "ver      : ",hex $ver,"\n";
    print $wfh "cardtype : ",hex $cardtype,"\n";
    print $wfh "time     : ",getfromtime(hex $time),"\n";
    print $wfh "time2    : ",hex $time2,"\n";
    print $wfh "netelem  : ",hex $netelement,"\n";
    print $wfh "interf   : ",hex $interface,"\n";
    print $wfh "dir      : ",hex $dir,"\n";

    print $wfh "\nSpecial package --\n";

    my $interfaceb = hex $interface;
    # UU message
    if ( $interfaceb =~ /\d+/ && $interfaceb == 1 ) {
	  $interfacecount{'UU'}++;
      my ($before,$uulen,$enbid,$cellid,$channeltype,$crnti,$mmeues1apid,$mmegroupid,$mmecode,$payload) = unpack('H26H2H8H4H2H4H8H4H2H*',$totalstr);
  	  print $wfh "uu len        : ",hex $uulen,"\n";
	  print $wfh "enbid         : ",hex $enbid,"\n";
	  print $wfh "cellid        : ",hex $cellid,"\n";
	  print $wfh "channeltype   : ",hex $channeltype,"\n";
	  print $wfh "crnti         : ",hex $crnti,"\n";
	  print $wfh "mmeues1apid   : ",hex $mmeues1apid,"\n";
	  print $wfh "mmegroupid    : ",hex $mmegroupid,"\n";
	  print $wfh "mmecode       : ",hex $mmecode,"\n";
      print $wfh "\npayload -- \n",$payload,"\n";

      print $uufh hex($ver),",",hex($cardtype),",",hex($time),",",hex($time2),",",hex($netelement),",",hex($interface),",",hex($dir),",",hex($channeltype),",",hex($enbid),",",hex($cellid),",",hex($crnti),",",hex($mmeues1apid),",",hex($mmegroupid),",",hex($mmecode),"\n";

	  my $enbidentity = hex $enbid;
      $enbcount{'UU'}{$enbidentity} = 0 unless ( defined($enbcount{'UU'}{$enbidentity}) );
	  $enbcount{'UU'}{$enbidentity}++;
    }
    # UU extend message
    elsif ( $interfaceb =~ /\d+/ && $interfaceb == 2 ) {
	  $interfacecount{'UU-EXT'}++;
      my ($before,$uulen,$sampletype,$enbid,$cellid,$crnti,$mmeues1apid,$mmegroupid,$mmecode,$payload) = unpack('H26H2H2H8H4H4H8H4H2H*',$totalstr);
  	  print $wfh "uu ext len    : ",hex $uulen,"\n";
  	  print $wfh "sampletype    : ",hex $sampletype,"\n";
	  print $wfh "enbid         : ",hex $enbid,"\n";
	  print $wfh "cellid        : ",hex $cellid,"\n";
	  print $wfh "crnti         : ",hex $crnti,"\n";
	  print $wfh "mmeues1apid   : ",hex $mmeues1apid,"\n";
	  print $wfh "mmegroupid    : ",hex $mmegroupid,"\n";
	  print $wfh "mmecode       : ",hex $mmecode,"\n";
      print $wfh "\npayload -- \n",$payload,"\n";

      print $uuextfh hex($ver),",",hex($cardtype),",",hex($time),",",hex($time2),",",hex($netelement),",",hex($interface),",",hex($dir),",",hex($sampletype),",",hex($enbid),",",hex($cellid),",",hex($crnti),",",hex($mmeues1apid),",",hex($mmegroupid),",",hex($mmecode),"\n";
      print $wfh "\nPayload UU Extend content --\n";
	  my $headbyte = 26 + 2 + 2 + 8 + 4 + 4 + 8 + 4 + 2; # sum total bytes before payload
	  my ($head,$parameterlen,$other) = unpack("H${headbyte}H2H*",$totalstr);
	  print $wfh "Parameter Len : ",hex $parameterlen,"\n\n";

	  my ($code,$value,$codeb);
	  $headbyte += 2;
	  for( my $i=0; $i<hex $parameterlen; $i++ ) {
	    # get Code
	    ($head,$codeb,$code,$value) = unpack("H${headbyte}H2H2H*",$totalstr);
	    my $valuebyte = $types{hex $code} * 2;
	    $headbyte += 4;

	    # get Value
	    ($head,$value,$other) = unpack("H${headbyte}H${valuebyte}H*",$totalstr);
	    print $wfh "type=",hex $code,",  ",hex $value,"\n";

	    $headbyte += $valuebyte;
	  }

	  my $enbidentity = hex $enbid;
      $enbcount{'UU-EXT'}{$enbidentity} = 0 unless ( defined($enbcount{'UU-EXT'}{$enbidentity}) );
	  $enbcount{'UU-EXT'}{$enbidentity}++;

	  if ( $uuextlasttime == 0 ) {
	    $uuextlasttime = hex $time;
	  }
	  else {
	    my $interval = hex($time) - $uuextlasttime ;
		#print "$uuextlasttime - ",hex $time,"\n";
	    $uuextlasttime = hex($time);
		$uuextsum += $interval;
		$uuextcount++;
		$uuextmax = $interval if ( $interval > $uuextmax );
		$uuextmin = $interval if ( $interval < $uuextmin );
	  }
    }
    # X2 message
    elsif ( $interfaceb =~ /\d+/ && $interfaceb == 3 ) {
	  #print "$_\n";
	  $interfacecount{'X2'}++;
      my ($before,$x2len,$sourceenbid,$destenbid,$cellid,$payload) = unpack('H26H2H8H8H4H*',$totalstr);
  	  print $wfh "x2 len        : ",hex $x2len,"\n";
	  print $wfh "source enb id : ",hex $sourceenbid,"\n";
	  print $wfh "dest enb id   : ",hex $destenbid,"\n";
	  print $wfh "cellid        : ",hex $cellid,"\n";
      print $wfh "\npayload -- \n",$payload,"\n";

      print $x2fh hex($ver),",",hex($cardtype),",",hex($time),",",hex($time2),",",hex($netelement),",",hex($interface),",",hex($dir),",",hex($sourceenbid),",",hex($destenbid),",",hex($cellid),"\n";

	  my $enbidentity = hex($sourceenbid)."-".hex($destenbid);
      $enbcount{'X2'}{$enbidentity} = 0 unless ( defined($enbcount{'X2'}{$enbidentity}) );
	  $enbcount{'X2'}{$enbidentity}++;
    }
	else {
	  print $wrongfh "Wrong interface value : $interfaceb\n";
	}

    print $wfh "\n";
	read( $fh,$data,1 );
  }

  close($x2fh);
  close($uufh);
  close($uuextfh);
  close($wfh);
  close($fh);
  $count = 0;
}
closedir(TD);
close($wrongfh);

## display statictics result

# interface
print "INTERFACE ---\n";
foreach (keys %interfacecount) {
  my $tmpkey = sprintf("%10s",$_);
  print "$tmpkey : $interfacecount{$_}\n";
}

# enb
print "ENB       ---\n";
foreach my $outter (keys %enbcount) {
  my $tmpout = sprintf("%10s",$outter);
  print "$tmpout :\n";
  foreach my $inner (keys %{$enbcount{$outter}}) {
    my $tmpinn = sprintf("%10s",$inner);
	print "$tmpinn : $enbcount{$outter}{$inner}\n";
  }
}

# periodicity of UU-ext
print "PERIODICITY --- (ONLY FOR UU-EXT)\n";
if ( $uuextcount == 0 ) {
  print "    No periodicity result.\n";
}
else {
  $uuextavg = $uuextsum / $uuextcount;
  print sprintf("%10s","MAX")," : $uuextmax\n";
  print sprintf("%10s","MIN")," : $uuextmin\n";
  print sprintf("%10s","AVG")," : $uuextavg\n";
}

# total message
print "\nTOTAL MESSAGE ---\n";
my $totalnumber = 0;
foreach (keys %interfacecount) {
  $totalnumber += $interfacecount{$_};
}
print sprintf("%10s","NUMBER")," : $totalnumber\n";

__END__

=head1 NAME

sdtpdecoder.pl

=head1 SYNOPSIS

perl sdtpdecoder.pl <sdtp data directory>

=head1 DESCRIPTION

SCA IF1 simulator's data file is always locate in ./data under SCA simulator's home directory, so the program can decode all files here.

a configuration file used here named "type.csv", for each item, there are two columns, first is parameter identity, second is byte length, both are defined in SCA spec documentation. Here is our current definition:

1,1

4,1

7,2

8,2

29,1

30,1

31,1


After decoding all data files, the program also generate a new csv file for each data file which may easy for third party tool to analysing. In the end, the program gives a simple statictics about all data files.

=head1 AUTHORS

Li Qinglu

=head1 COPYRIGHT

Copyright (c) 2014-  All rights reserved.This program is free software; you may redistribute it and/ormodify it under the same terms as Perl itself.

=cut
